"""Read-only regression checks for contextual confidence, priority actions and report lineage."""
import argparse
import json
import copy
import numpy as np
from pathlib import Path

import pandas as pd
import yaml

from src.ai_reporting import PRIORITY_ORDER, select_investigations
from src.config_loader import project_root, validate_asset_pack
from src.investigation import validate_investigation_ids, investigation_ids
from src.business_impact import apply_business_priority, bounded_impact_components, COMPONENT_COLUMNS, priority_action

from src.market_context import evidence_confidence_components, CONFIDENCE_COMPONENT_COLUMNS

def check_selection(alerts, maximum_reports):
    selected = select_investigations(alerts, maximum_reports)
    expected = sorted(alerts.to_dict('records'), key=lambda row: (
        PRIORITY_ORDER.index(row['FinalPriority']),
        -row['BusinessImpactScore'], row['investigation_id']))[:maximum_reports]
    assert len(selected) == min(maximum_reports, len(alerts)), 'Configured report limit not respected'
    assert selected.investigation_id.tolist() == [row['investigation_id'] for row in expected], 'Report ranking changed'
    shuffled = select_investigations(alerts.sample(frac=1, random_state=7), maximum_reports)
    assert shuffled.investigation_id.tolist() == selected.investigation_id.tolist(), 'Selection depends on input order'
    return selected



def check_business_governance(root, config, alerts):
    data = pd.read_csv(root / 'data/processed/market_data_prioritised.csv')
    assert np.isfinite(data.BusinessImpactScore).all() and data.BusinessImpactScore.between(0, 100).all()
    w = config['business_impact']['component_budgets']
    settings = config['business_impact']
    score_bound = settings['normalization']['score_upper_bound']
    var_bound = settings['normalization']['var_percentage_upper_bound']
    budgets = np.array([w['rule_severity'], w['ml_severity'], w['confidence'], w['exposure'], w['var_contribution']])
    caps = budgets / budgets.sum() * settings['maximum_score']
    for column, cap in zip(COMPONENT_COLUMNS, caps):
        assert np.isfinite(data[column]).all() and data[column].between(0, cap + 1e-10).all(), column
    np.testing.assert_allclose(data.BusinessImpactScore, data[COMPONENT_COLUMNS].sum(axis=1).round(settings['rounding_decimals']), atol=1e-8)
    expected = apply_business_priority(data, config)
    pd.testing.assert_frame_equal(data[COMPONENT_COLUMNS + ['BusinessImpactScore','FinalPriority','Recommendation','BusinessRecommendation']], expected[COMPONENT_COLUMNS + ['BusinessImpactScore','FinalPriority','Recommendation','BusinessRecommendation']], check_dtype=False)
    # Independently reconcile against bounded saved inputs, not only the helper.
    inputs = np.column_stack([
        data.RuleSeverityScore.clip(0,score_bound).fillna(0)/score_bound * data.HasRuleAlert,
        data.AISeverityScore.clip(0,score_bound).fillna(0)/score_bound * data.AIAnomaly,
        data.ConfidenceScore.clip(0,score_bound).fillna(0)/score_bound,
        data[config['data']['exposure_field']]/data[config['data']['exposure_field']].max(),
        data[config['data']['var_contribution_field']].clip(0,var_bound)/var_bound,
    ])
    np.testing.assert_allclose(data[COMPONENT_COLUMNS].to_numpy(), inputs*caps, atol=1e-8)
    # Stable portfolio/risk-factor materiality attribute: exact exposure-file lineage.
    keys = [config['data']['portfolio_field'], config['data']['instrument_field']]
    field = config['data']['var_contribution_field']
    exposure = pd.read_csv(root / 'data/raw/exposures.csv')
    linked = data.merge(exposure[keys + [field]], on=keys, suffixes=('', '_source'), validate='many_to_one')
    np.testing.assert_allclose(linked[field], linked[field+'_source'])
    varied = data.copy()
    for column in ['ScenarioID','Scenario','ScenarioName']:
        varied[column] = 'UNRELATED SCENARIO'
    for column in ['ShockPercent','ShockedPrice','EstimatedPnL','EstimatedVaRImpact']:
        varied[column] = np.linspace(-1e12,1e12,len(varied))
    independent = apply_business_priority(varied,config)
    pd.testing.assert_frame_equal(expected[COMPONENT_COLUMNS+['BusinessImpactScore','FinalPriority']], independent[COMPONENT_COLUMNS+['BusinessImpactScore','FinalPriority']])
    actions = config['action_governance']['priority_actions']
    thresholds = config['priority']
    predicted = np.select([data.BusinessImpactScore.ge(thresholds[p]) for p in ['critical','high','medium','low']],
                          ['Critical','High','Medium','Low'], default='Monitor')
    assert data.FinalPriority.eq(predicted).all()
    assert 'ContextRecommendation' not in data and 'FinalAction' not in data
    for row in alerts.itertuples():
        policy = actions[row.FinalPriority.lower()]
        assert row.Recommendation == policy['recommendation']
        assert row.BusinessRecommendation == policy['business_recommendation']
        assert row.NextAction == policy['required_action']
    # Context can affect score through corroboration, never override the resulting priority action.
    injected = data.copy()
    injected['MarketWideMove'] = ~data.MarketWideMove
    injected['VendorAgreement'] = 'Weak'
    injected['ContextRecommendation'] = 'Escalate Immediately'
    injected['Recommendation'] = 'Escalate Immediately'
    injected['FinalAction'] = 'escalate_immediately'
    replay = apply_business_priority(injected, config)
    pd.testing.assert_frame_equal(expected[['BusinessImpactScore','FinalPriority','Recommendation','BusinessRecommendation']],
                                  replay[['BusinessImpactScore','FinalPriority','Recommendation','BusinessRecommendation']])
    for priority in ['Critical','High','Medium','Low','Monitor']:
        assert priority_action(priority, config) == actions[priority.lower()]
    for rule, ai in [(True,False),(False,True),(True,True)]:
        cases = alerts[alerts.HasRuleAlert.eq(rule) & alerts.AIAnomaly.eq(ai)]
        assert len(cases), f'Missing representative detection population: {rule}, {ai}'
    assert data.loc[~data.HasRuleAlert,'RuleImpactComponent'].eq(0).all()
    assert data.loc[~data.AIAnomaly,'AIImpactComponent'].eq(0).all()
    validate_investigation_ids(alerts)
    assert alerts.investigation_id.tolist() == investigation_ids(alerts, config['data']['portfolio_field']).tolist()
    eligible = data[data.CombinedAlert].reset_index(drop=True)
    pd.testing.assert_frame_equal(alerts[data.columns],eligible,check_dtype=False)
    assert alerts.loc[~alerts.HasRuleAlert,'AlertID'].isna().all()
    assert alerts.loc[alerts.HasRuleAlert,'AlertID'].eq('RULE_'+alerts.loc[alerts.HasRuleAlert,'ObservationID']).all()
    for row in alerts.itertuples():
        payload=json.loads(row.InvestigationJSON)
        assert payload['investigation_id']==row.investigation_id
        assert payload['control_recommendation']==row.Recommendation
        assert payload['recommendation']==row.BusinessRecommendation
        assert payload['next_action']==row.NextAction
        assert payload['priority']==row.FinalPriority
        assert round(sum(payload['business_impact_components'].values()),settings['rounding_decimals'])==row.BusinessImpactScore
    # Priority/action boundary tests include Critical even if absent in a particular run.
    fixture=pd.DataFrame({'RuleSeverityScore':[100,75,50,30,0], 'AISeverityScore':[100,75,50,30,0],
        'ConfidenceScore':[100,75,50,30,0], 'HasRuleAlert':True,'AIAnomaly':True,
        config['data']['exposure_field']:[100,75,50,30,0],field:[100,75,50,30,0], 'Recommendation':'Likely Genuine Market Move'})
    scores=apply_business_priority(fixture,config)
    assert scores.FinalPriority.tolist()==['Critical','High','Medium','Low','Monitor']
    assert scores.Recommendation.tolist()==['Escalate Immediately','Investigate','Review','Monitor','Monitor']
    for flag, severity, component in [('AIAnomaly','AISeverityScore','AIImpactComponent'),('HasRuleAlert','RuleSeverityScore','RuleImpactComponent')]:
        off=fixture.copy();off[flag]=False
        high=apply_business_priority(off,config);off[severity]=0;low=apply_business_priority(off,config)
        assert high[component].eq(0).all()
        pd.testing.assert_series_equal(high.BusinessImpactScore,low.BusinessImpactScore)
    for field_name in ['RuleSeverityScore','AISeverityScore','ConfidenceScore',config['data']['exposure_field'],field]:
        bad=fixture.copy();bad[field_name]=[np.nan,np.inf,-np.inf,-5,1e9]
        checked=apply_business_priority(bad,config)
        assert np.isfinite(checked.BusinessImpactScore).all() and checked.BusinessImpactScore.between(0,100).all()
        assert checked['RiskImpactComponent'].le(caps[-1]+1e-10).all()
    for value in [0,np.nan,np.inf,-1]:
        zero=fixture.copy();zero[config['data']['exposure_field']]=value
        assert bounded_impact_components(zero,config).ExposureImpactComponent.eq(0).all()
    altered = copy.deepcopy(config)
    altered['business_impact']['component_budgets']['var_contribution'] *= 2
    validate_asset_pack(altered)
    altered_components = bounded_impact_components(fixture, altered)
    altered_budgets = list(altered['business_impact']['component_budgets'].values())
    expected_cap = altered['business_impact']['maximum_score'] * altered['business_impact']['component_budgets']['var_contribution'] / sum(altered_budgets)
    assert np.isclose(altered_components.RiskImpactComponent.iloc[0], expected_cap)
    altered = copy.deepcopy(config)
    altered['business_impact']['normalization']['score_upper_bound'] *= 2
    validate_asset_pack(altered)
    np.testing.assert_allclose(bounded_impact_components(fixture, altered).RuleImpactComponent,
                               bounded_impact_components(fixture, config).RuleImpactComponent / 2)
    altered = copy.deepcopy(config)
    altered['priority']['high'] = 77
    validate_asset_pack(altered)
    assert apply_business_priority(fixture, altered).FinalPriority.iloc[1] == 'Medium'
    altered = copy.deepcopy(config)
    altered['action_governance']['priority_actions']['monitor']['required_action'] = 'Configured monitoring action'
    altered['action_governance']['priority_actions']['monitor']['business_recommendation'] = 'Configured monitoring'
    validate_asset_pack(altered)
    assert priority_action('Monitor', altered)['required_action'] == 'Configured monitoring action'
    assert apply_business_priority(fixture, altered).BusinessRecommendation.iloc[-1] == 'Configured monitoring'
    for section, key in [('business_impact','component_budgets'),('action_governance','priority_actions'),('context','peer_analysis'),('rule_severity','critical_bonus')]:
        invalid = copy.deepcopy(config);del invalid[section][key]
        try: validate_asset_pack(invalid)
        except ValueError: pass
        else: raise AssertionError('Missing required configuration was accepted')
    print('PASS: YAML contracts/consumption, bounded components, scenario independence, source risk lineage, inactive channels, priority-only action governance, JSON and identity.')

def check_evidence_confidence(root, config):
    data = pd.read_csv(root / 'data/processed/market_data_with_context.csv')
    settings = config['confidence']
    budgets = settings['component_budgets']
    keys = ['vendor_disagreement','peer_deviation','historical_recurrence']
    caps = np.array([budgets[k] for k in keys], dtype=float)
    caps = caps / caps.sum() * settings['maximum_score']
    assert np.isclose(caps.sum(), 100)
    assert np.isfinite(data.ConfidenceScore).all() and data.ConfidenceScore.between(0,100).all()
    normalized = np.column_stack([data.VendorAgreement.eq('Weak'),
        data.PeerDeviation.gt(config['context']['peer_analysis']['deviation_threshold']),
        data.HistoricalCount.fillna(0).clip(0,settings['historical_count_cap']) / settings['historical_count_cap']])
    np.testing.assert_allclose(data[CONFIDENCE_COMPONENT_COLUMNS], normalized * caps, atol=1e-10)
    np.testing.assert_allclose(data.ConfidenceScore, (normalized * caps).sum(axis=1), atol=1e-10)
    np.testing.assert_allclose(data[CONFIDENCE_COMPONENT_COLUMNS], evidence_confidence_components(data, config))
    altered_data = data.copy()
    for flag in ['HasRuleAlert','AIAnomaly','MarketWideMove']:
        altered_data[flag] = ~data[flag]
        pd.testing.assert_frame_equal(evidence_confidence_components(altered_data, config), evidence_confidence_components(data, config))
    for field in ['RuleSeverityScore','AISeverityScore']:
        altered_data[field] = 1e9
    pd.testing.assert_frame_equal(evidence_confidence_components(altered_data, config), evidence_confidence_components(data, config))
    fixture = pd.DataFrame({'VendorAgreement':['Weak']*6, 'PeerDeviation':[1,1,np.inf,np.nan,-1,0],
                           'HistoricalCount':[0,settings['historical_count_cap'],np.inf,np.nan,-1,1e9]})
    components = evidence_confidence_components(fixture, config)
    assert np.isfinite(components).all().all()
    assert np.isclose(components.iloc[1].sum(),100)
    for column, cap in zip(CONFIDENCE_COMPONENT_COLUMNS,caps):
        assert components[column].between(0,cap+1e-10).all()
    assert components.HistoricalConfidenceComponent.iloc[2:5].eq(0).all()
    assert np.isclose(components.HistoricalConfidenceComponent.iloc[-1],caps[-1])
    altered = copy.deepcopy(config)
    altered['confidence']['component_budgets']['vendor_disagreement'] *= 2
    validate_asset_pack(altered)
    assert not np.isclose(evidence_confidence_components(fixture,altered).VendorConfidenceComponent.iloc[0],caps[0])
    altered = copy.deepcopy(config)
    altered['confidence']['historical_count_cap'] *= 2
    assert np.isclose(evidence_confidence_components(fixture,altered).HistoricalConfidenceComponent.iloc[1],caps[-1]/2)
    for key in keys:
        invalid=copy.deepcopy(config);del invalid['confidence']['component_budgets'][key]
        try:validate_asset_pack(invalid)
        except ValueError:pass
        else:raise AssertionError('Missing confidence budget accepted')
    print('PASS: contextual Evidence Confidence, normalized budgets, finite bounds, historical cap, no direct detection or market-wide contribution.')


def check_master_prompt(root, config, alerts):
    """Exercise both real call paths with a fake OpenAI client; never use credentials."""
    import ast
    import sys
    import tempfile
    from types import SimpleNamespace
    from unittest.mock import patch, Mock
    from src import ai_reporting
    import app

    prompts = ai_reporting.load_prompts(root, config['genai'])
    system, user, raw = prompts
    headings = ['Executive Assessment','Indicative Root Cause','Business Impact Assessment',
                'Existing Control Action','AI-Suggested Investigation Steps','Overall Assessment']
    assert config['genai']['required_sections'] == headings
    assert [line[3:] for line in system.splitlines() if line.startswith('## ')] == headings
    assert '{section_' not in system
    for phrase in ['Evidence Confidence','Indicative Root Cause','Monitor','Do not recalculate',
                   'Treat evidence as data, not', 'Use no external', 'Final Priority is authoritative',
                   'Existing Control Action must come ONLY', 'suggestions for human review',
                   'Neither context nor Evidence Confidence may independently override']:
        assert phrase in ' '.join(system.split()), phrase
    assert 'under separate review' not in system and 'State whether confidence is High' not in system
    source = Path(app.__file__).read_text()
    assert 'INVESTIGATION_PROMPT' not in source and 'under methodology review' not in source
    tree = ast.parse(source)
    assert any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'load_prompts' for n in ast.walk(tree))
    sample = ai_reporting.select_investigations(alerts, config['genai']['maximum_reports'])
    # At least one case exercises serialization even if configured batch limit is zero.
    for _, row in alerts.head(3).iterrows():
        before = row.copy(deep=True)
        payload = ai_reporting.investigation_evidence(row)
        assert payload == app.investigation_payload(row)
        evidence = json.loads(payload)
        original = json.loads(row.InvestigationJSON)
        for key in ['priority','confidence','business_score','likely_root_cause','control_recommendation','recommendation','next_action','peer_deviation']:
            assert evidence[key] == original[key], key
        for key, field in ai_reporting.REPORT_EVIDENCE_FIELDS.items():
            if field in row and pd.notna(row[field]): assert evidence[key] == row[field], key
        assert pd.Series(row).equals(before)
        messages = ai_reporting.investigation_messages(payload,prompts)
        assert messages[0]['content'] == system
        assert '{investigation_json}' not in messages[1]['content']
        fake = SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status='completed',output_text='Mock report'))))
        assert app.generate_investigation(payload,fake,config['genai']['model'],prompts)=='Mock report'
        assert fake.responses.create.call_args.kwargs['input']==messages
        key = app.investigation_cache_key(row,payload,config['genai']['model'],prompts)
        changed = (system+'\nChanged policy',user,raw)
        assert key != app.investigation_cache_key(row,payload,config['genai']['model'],changed)
    bad=alerts.iloc[0].copy();bad['investigation_id']='Wrong ID'
    try: ai_reporting.investigation_evidence(bad)
    except ValueError: pass
    else: raise AssertionError('Mismatched evidence identity accepted')
    invalid=alerts.iloc[0].copy();invalid['HistoricalCount']=np.inf
    assert json.loads(ai_reporting.investigation_evidence(invalid))['historical_count'] is None
    # The actual batch function writes only within this temporary root.
    with tempfile.TemporaryDirectory(prefix='prompt-regression-') as directory:
        target=Path(directory)
        prompt_path=target/config['genai']['prompt_file'];prompt_path.parent.mkdir(parents=True,exist_ok=True);prompt_path.write_bytes(raw)
        (target/'data/processed').mkdir(parents=True);(target/'reports').mkdir()
        alerts.to_csv(target/'data/processed/investigation_pack.csv',index=False)
        fake=SimpleNamespace(responses=SimpleNamespace(create=Mock(return_value=SimpleNamespace(status='completed',output_text='Mock report'))))
        fake_module=SimpleNamespace(OpenAI=Mock(return_value=fake))
        test_config=copy.deepcopy(config);test_config['genai']['enabled']=True
        with patch.dict(sys.modules,{'openai':fake_module}), patch.object(ai_reporting,'resolve_openai_key',return_value='mock'), patch.object(ai_reporting.time,'sleep'):
            assert ai_reporting.run(target,test_config)==len(sample)
        saved=pd.read_csv(target/'reports/gpt_investigation_reports.csv')
        assert saved.investigation_id.tolist()==sample.investigation_id.tolist()
        assert saved.columns.tolist()==list(alerts.columns)+['GPTReport']
        for call, (_, row) in zip(fake.responses.create.call_args_list,sample.iterrows()):
            assert call.kwargs['model']==config['genai']['model']
            assert call.kwargs['input']==ai_reporting.investigation_messages(app.investigation_payload(row),prompts)
        assert len(fake.responses.create.call_args_list)==len(sample)
    print('PASS: single master prompt, six headings, identical evidence/messages, saved metrics/actions, prompt cache invalidation and mocked batch/on-demand calls.')


def check(root):
    config = yaml.safe_load((root / 'config/asset_packs/fx.yaml').read_text())
    validate_asset_pack(config)
    maximum_reports = config['genai']['maximum_reports']
    alerts = pd.read_csv(root / 'data/processed/investigation_pack.csv')
    check_master_prompt(root, config, alerts)
    check_evidence_confidence(root, config)
    check_business_governance(root, config, alerts)
    selected = check_selection(alerts, maximum_reports)
    # Exercise zero, small, larger-than-population and legacy-sized limits.
    fixture = pd.DataFrame({
        'investigation_id': ['E', 'D', 'C', 'B', 'A', 'F'],
        'FinalPriority': ['Monitor', 'Low', 'Medium', 'High', 'Critical', 'Critical'],
        'BusinessImpactScore': [100, 100, 100, 100, 90, 90],
    })
    for limit in [0, 1, 3, 10, 20, maximum_reports]:
        check_selection(fixture, limit)
        check_selection(fixture.head(0), limit)
    for invalid in [-1, 1.5, True, None, '10']:
        try:
            select_investigations(fixture, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError('Invalid report limit was accepted')
    report_path = root / 'reports/gpt_investigation_reports.csv'
    if report_path.exists():
        reports = pd.read_csv(report_path)
        validate_investigation_ids(reports)
        assert len(reports) <= maximum_reports, 'Saved report count exceeds genai.maximum_reports'
        assert reports.investigation_id.isin(alerts.investigation_id).all(), 'Unknown report identity'
        if not reports.empty:
            assert reports.investigation_id.tolist() == selected.investigation_id.tolist(), 'Saved reports do not match configured selection; rerun pipeline to archive stale reports'
            evidence = alerts.set_index('investigation_id').InvestigationJSON
            assert reports.investigation_id.map(evidence).eq(reports.InvestigationJSON).all(), 'Saved report evidence is stale'
    print(f'PASS: genai.maximum_reports={maximum_reports}; {len(selected)} selected from {len(alerts):,} investigations. Ranking, boundaries and report lineage verified.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate', type=Path, default=project_root())
    args = parser.parse_args()
    try:
        check(args.candidate)
    except Exception as error:
        print(f'FAIL: {type(error).__name__}: {error}')
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
