# Local analytical pipeline

`run_pipeline.py` runs the analytical processing layer. `app.py` remains the separate Streamlit presentation and investigation layer. The implementation follows `VaR_Main_Code_Config_Driven.ipynb` Blocks 1–9; it does not execute the notebook at runtime.

## Setup and commands

Use Python 3.11 or newer (standard-library `tomllib` is used for secrets).

```bash
cd /Users/debabrata/Documents/var_control_cockpit_v4
# Create an environment only if one does not already exist:
python3 -m venv .venv
source .venv/bin/activate
python -m pip install pandas numpy scikit-learn PyYAML openai
```

Run the analytical pipeline without OpenAI:

```bash
python run_pipeline.py
python run_pipeline.py --help
```

This regenerates synthetic sources and analytical CSVs in the selected project. It overwrites the same output filenames as the notebook. Do not run the notebook and local pipeline concurrently against the same folder. An analytical failure exits nonzero and identifies its stage; earlier stages may already have written their outputs, so resolve the failure and rerun before refreshing the cockpit.

To generate GPT investigation reports as well:

```bash
python run_pipeline.py --generate-ai-reports
```

AI reporting requires both the CLI flag and `genai.enabled` in the existing Asset Control Pack. It loads the existing prompt path configured by `genai.prompt_file`, uses the configured model, priority selection, report limit and delay, and sends only each saved `InvestigationJSON`. No substitute prompt is embedded in Python.

OpenAI credentials are resolved in this order:

1. A nonempty `OPENAI_API_KEY` environment variable.
2. Otherwise, the root `OPENAI_API_KEY` entry in `.streamlit/secrets.toml`.
3. Otherwise, skip AI reporting with a clear message, preserving analytical outputs.

Secrets are read only and never printed or copied into configuration/audit files. Individual API failures retain the notebook-compatible `LLM Error:` report marker with generic text, without recording raw exception details. AI tests used mocked responses; live OpenAI access and narrative quality were not tested.

The default run leaves an existing `reports/gpt_investigation_reports.csv` intact. On a first run it creates an empty file with the compatible columns. Existing saved reports relate to their original alert identities; a new current-time run does not regenerate those narratives unless AI reporting is requested.

Run the cockpit separately:

```bash
# Its existing dependencies, if not already installed:
python -m pip install streamlit plotly jsonschema
export MARKET_RISK_BASE_PATH="$PWD"
streamlit run app.py
```

The pipeline locates the project relative to `run_pipeline.py`, independent of Terminal's current directory. Set `MARKET_RISK_BASE_PATH` to use another existing project root containing the same config paths. The unchanged Streamlit app also supports this environment variable; set it as above to select local files instead of its existing Colab default.

## Notebook mapping

| Notebook block | Local implementation |
| --- | --- |
| 1: setup, pack validation, seeds, audit | `run_pipeline.py`, `src/config_loader.py` |
| 2: synthetic sources | `src/data_generation.py` |
| 3: enrichment and features | `src/enrichment.py` |
| 4: unique-observation rules, severity, evidence, quality gates, portfolio merge | `src/rule_engine.py` |
| 5: scaling, Isolation Forest, anomaly scores | `src/anomaly_detection.py` |
| 6: market context, historical context, confidence | `src/market_context.py` |
| 7: scenarios, prototype impact and priority | `src/business_impact.py` |
| 8: root-cause precedence and Investigation Pack | `src/investigation.py` |
| 9: existing prompt, optional GPT reports | `src/ai_reporting.py` |

Each stage has an explicit `run(project_root, config)` function and retains the notebook's CSV handoffs and section comments. Block 2 additionally accepts an optional synthetic history end time. There is no shared notebook variable namespace, Google Drive mount, Colab secret dependency, `/content/drive` path, runtime code evaluation, or notebook magic in the pipeline.

The existing YAML remains authoritative for all values that the notebook reads from it. Prototype constants already embedded in the notebook remain in the corresponding module. Configuration and prompt audit snapshots retain the notebook's lineage behavior under `audit/`; these are historical snapshots, not alternative configuration sources. No source configuration/prompt file is rewritten.

Notebook chart rendering and dataframe printing have been removed. Calls to unseeded chart `.sample()` remain, with comments, because consuming the same random draws is necessary to preserve later scenario assignment. Both original seeds, draw order, dataframe order, and the Isolation Forest parameters are retained.

PeerDeviation retains the notebook's existing price-level methodology and its TODO for a separate analytical review. No analytical correction is included here. P&L and VaR-impact values are **prototype analytical risk-impact estimates, not regulatory VaR or Expected Shortfall calculations**.

## Outputs

The pipeline retains all four synthetic raw CSVs, all nine processed CSVs specified by the notebook, `reports/block4_rule_quality_checks.csv`, `reports/block4_rule_summary.csv`, and the compatible `reports/gpt_investigation_reports.csv` contract. Column names and order are preserved. No new model persistence format is introduced.

## Reproducibility and regression

The notebook generates timestamps ending at `pd.Timestamp.today()`. Consequently, a new default run intentionally has new timestamps/observation IDs, calendar context and potentially different evidence wording. Seeds alone cannot reproduce the calendar of an earlier run.

To compare to a saved reference, supply its maximum timestamp from `data/raw/market_data.csv`:

```bash
python run_pipeline.py --as-of '2026-09-08 16:53:41.508673'
python regression_check.py --baseline /path/to/reference_project --candidate "$PWD"
```

Use the same configuration and dependency environment for the closest comparison. `--as-of` only supplies the end timestamp to the notebook's existing date-range expression; its default remains current time. It does not change any risk formula or random draw.

`regression_check.py` reads both directories without writing. It returns exit code 0 for PASS and 1 for FAIL and checks 15 analytical/source/report CSVs for existence, row counts, ordered schemas, categorical/identifier values, row order, numerical values, priority and detection counts. Investigation JSON is compared recursively, including evidence numbers with tolerance. The Python-dict display serialization is checked for presence; its evidence values are checked through `InvestigationJSON`. GPT report columns are checked; optional generated narrative text is not expected to be deterministic.

Default tolerances are `rtol=1e-9`, `atol=1e-8`; both can be overridden. Timestamps/identifiers are compared exactly. Nothing is automatically normalized or excluded to make a comparison pass. To deliberately compare runs made at different timestamps, first reproduce the reference timestamp; otherwise differences correctly cause failure.

### Validation of this refactor

**Regression equivalence confirmed** against the actual saved V4 CSVs using their history end timestamp above.

| Metric | Saved baseline | Local pipeline |
| --- | ---: | ---: |
| Portfolio Alerts | 7,556 | 7,556 |
| Critical | 1,362 | 1,362 |
| High | 1,581 | 1,581 |
| Medium | 1,612 | 1,612 |
| Low | 2,559 | 2,559 |
| Monitor | 442 | 442 |
| Alerts with AI Detection | 432 | 432 |
| Alerts with Rule Detection | 7,408 | 7,408 |
| Rule Only | 7,124 | 7,124 |
| AI Only | 148 | 148 |
| Rule + AI | 284 | 284 |

All categorical fields, IDs, row order, output schemas, priorities and structured evidence matched. Floating-point differences were within tolerance: the maximum observed absolute difference across compared numeric CSV columns was `5.820766091346741e-11`; the prioritised dataset maximum was `1.2989609388114332e-13`. No score/priority/detection-count changes occurred.

Validation environment: Python 3.14.5, pandas 3.0.5, NumPy 2.5.3, scikit-learn 1.9.0, PyYAML 6.0.3. The original saved files remain the authoritative baseline; production logic contains no expected-count constants.

Additional checks covered compilation, CLI help, configuration validation, missing/malformed input handling, stage failure stopping execution, environment/TOML credential precedence with synthetic secrets, no-key AI skip, unchanged YAML template formatting, mocked report success/failure, and comparator sensitivity to a numerical change. The unchanged Streamlit app rendered all four pages and its priority filter correctly using the generated CSVs.

Protected files were checked by SHA-256 and remained unchanged: `app.py`, `VaR_Main_Code_Config_Driven.ipynb`, `config/asset_packs/fx.yaml`, every existing file under `config/prompts/`, and `.streamlit/secrets.toml`.

Git status: this V4 folder was not a Git repository and had no `.gitignore` at validation time, so `.streamlit/secrets.toml` could not be confirmed as ignored. Neither Git configuration nor `.gitignore` was changed. Establish secret exclusions before adding the project to Git.
