"""Local analytical entry point; Streamlit runs separately. Requires Python 3.11+."""
import argparse
import json
import logging
import random


def main(argv=None):
    parser = argparse.ArgumentParser(description='Run notebook-equivalent Blocks 2–8 locally using the existing FX pack.')
    parser.add_argument('--generate-ai-reports', action='store_true', help='Also run Block 9 using the existing YAML prompt and OpenAI credentials.')
    parser.add_argument('--as-of', help='Optional synthetic history end timestamp for baseline replay; default is current time, as in the notebook.')
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    stage = 'Loading FX Asset Control Pack'
    try:
        import numpy as np
        import pandas as pd
        from src.config_loader import project_root, load_asset_pack
        from src import data_generation, enrichment, rule_engine, anomaly_detection, market_context, business_impact, investigation
        root = project_root()
        logging.info('[1/8] %s', stage)
        config, _ = load_asset_pack(root / 'config/asset_packs/fx.yaml', root)
        if args.as_of is not None:
            pd.Timestamp(args.as_of)  # Fail before generating any source datasets.
        for folder in ['data/raw', 'data/processed', 'outputs', 'audit', 'reports', 'models']:
            (root / folder).mkdir(parents=True, exist_ok=True)
        random.seed(config['prototype']['random_seed'])
        np.random.seed(config['prototype']['random_seed'])
        legacy = {key: config['prototype'][key] for key in ['project_name', 'version', 'random_seed', 'currency_pairs', 'days_of_history']}
        legacy['sampling_frequency'] = config['prototype']['audit_sampling_frequency']
        with (root / 'audit/config.json').open('w') as handle:
            json.dump(legacy, handle, indent=4)
        stages = [
            ('Generating synthetic datasets', data_generation),
            ('Running enrichment', enrichment),
            ('Running deterministic controls', rule_engine),
            ('Running Isolation Forest', anomaly_detection),
            ('Adding market context', market_context),
            ('Calculating prototype business impact', business_impact),
            ('Building Investigation Pack', investigation),
        ]
        for number, (stage, module) in enumerate(stages, 2):
            logging.info('[%s/8] %s', number, stage)
            if module is data_generation:
                module.run(root, config, as_of=args.as_of)
            else:
                module.run(root, config)
        # Preserve historical narratives in an archive, not under current evidence.
        stage = 'Ensuring report output contract'
        from src.ai_reporting import ensure_report_contract
        ensure_report_contract(root, config)
        if args.generate_ai_reports:
            stage = 'AI reporting (Block 9)'
            logging.info('[AI] %s', stage)
            from src.ai_reporting import run
            run(root, config)
        logging.info('Pipeline completed successfully.\nAnalytical outputs: %s\nReports: %s', root / 'data/processed', root / 'reports')
        return 0
    except Exception as error:
        # No raw exception payload from the AI/secret stage is ever printed.
        if stage == 'AI reporting (Block 9)':
            logging.error('FAILED [%s]: %s. Check prompt/configuration and output permissions; analytical outputs are retained.', stage, type(error).__name__)
        else:
            logging.error('FAILED [%s]: %s: %s', stage, type(error).__name__, error)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
