"""Block 9: original YAML templates and Investigation Pack report contract."""
import logging
import json
import math
import shutil
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from string import Formatter

import pandas as pd
import yaml


def resolve_openai_key(root):
    """Environment first, then read-only Streamlit TOML; never log credentials."""
    value = os.environ.get('OPENAI_API_KEY')
    if isinstance(value, str) and value.strip():
        return value.strip()
    path = Path(root) / '.streamlit/secrets.toml'
    if not path.is_file():
        return None
    try:
        import tomllib
        with path.open('rb') as handle:
            value = tomllib.load(handle).get('OPENAI_API_KEY')
    except (OSError, ValueError):
        logging.warning('AI reporting skipped: Streamlit secrets could not be read as TOML.')
        return None
    return value.strip() if isinstance(value, str) and value.strip() else None


def load_prompts(root, genai):
    """Load the single governed prompt with strict placeholder validation."""
    path = Path(root) / genai['prompt_file']
    if not path.is_file():
        raise FileNotFoundError(f'Missing investigation prompt: {path}')
    raw = path.read_bytes()
    try:
        config = yaml.safe_load(raw)
    except yaml.YAMLError:
        raise ValueError(f'Invalid investigation prompt YAML: {path}') from None
    if not isinstance(config, dict):
        raise ValueError('Prompt YAML must contain system_prompt and user_prompt.')

    def template(name, required):
        value = config.get(name)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f'Prompt YAML: {name} must be a non-empty string.')
        try:
            parsed = list(Formatter().parse(value))
        except ValueError:
            raise ValueError(f'Prompt YAML: invalid braces in {name}.') from None
        fields = {field for _, field, _, _ in parsed if field is not None}
        if fields != set(required) or any(spec or conversion for _, _, spec, conversion in parsed):
            raise ValueError(f'Prompt YAML: invalid placeholders in {name}.')
        return value

    sections = {f'section_{i + 1}': heading for i, heading in enumerate(genai['required_sections'])}
    system = template('system_prompt', sections).format(**sections)
    user = template('user_prompt', {'investigation_json'})
    return system, user, raw



# Supplement existing JSON only with values already saved on the same pack row.
REPORT_EVIDENCE_FIELDS = {
    'rule_severity': 'RuleSeverity', 'rule_severity_score': 'RuleSeverityScore',
    'ml_severity': 'AISeverity', 'ml_severity_score': 'AISeverityScore',
    'ml_feature_signals': 'AIExplanation', 'historical_count': 'HistoricalCount',
    'portfolio_risk_contribution': 'VaRContribution',
    'vendor_confidence_component': 'VendorConfidenceComponent',
    'peer_confidence_component': 'PeerConfidenceComponent',
    'historical_confidence_component': 'HistoricalConfidenceComponent',
}


def investigation_evidence(pack):
    """Serialize saved evidence identically for both paths; no scoring or inference."""
    if pack is None or 'InvestigationJSON' not in pack:
        raise ValueError('No existing structured Investigation Pack is available.')
    payload = pack['InvestigationJSON']
    if not isinstance(payload, str) or not payload.strip() or len(payload) > 50000:
        raise ValueError('The saved Investigation Pack is empty, invalid or too large.')
    try:
        parsed = json.loads(payload)
    except (ValueError, TypeError):
        raise ValueError('The saved Investigation Pack is not valid JSON.') from None
    if not isinstance(parsed, dict) or not parsed or 'priority' not in parsed:
        raise ValueError('The saved Investigation Pack must contain saved priority.')
    identity = pack.get('investigation_id')
    if not isinstance(identity, str) or not identity.strip() or parsed.get('investigation_id') != identity:
        raise ValueError('The saved Investigation Pack JSON does not match the selected Investigation ID.')
    for key, column in REPORT_EVIDENCE_FIELDS.items():
        if key not in parsed and column in pack:
            parsed[key] = pack[column]

    def safe(value):
        if isinstance(value, dict):
            return {key: safe(item) for key, item in value.items()}
        if isinstance(value, list):
            return [safe(item) for item in value]
        if pd.isna(value):
            return None
        if hasattr(value, 'item'):
            value = value.item()
        if isinstance(value, float) and not math.isfinite(value):
            return None
        return value
    return json.dumps(safe(parsed), ensure_ascii=False, allow_nan=False)


def investigation_messages(payload, prompts):
    """Render the same system and user templates for batch and on-demand calls."""
    system, user, _ = prompts
    return [{'role': 'system', 'content': system},
            {'role': 'user', 'content': user.format(investigation_json=payload)}]


PRIORITY_ORDER = ['Critical', 'High', 'Medium', 'Low', 'Monitor']


def ensure_report_contract(root, config):
    """Archive stale evidence/legacy reports; never relabel historical narratives.

    A no-OpenAI run leaves a compatible empty report file if no current reports
    exist. Previously valid narratives are retained only against identical packs.
    """
    packs = pd.read_csv(root / 'data/processed/investigation_pack.csv')
    path = root / 'reports/gpt_investigation_reports.csv'
    if path.exists():
        saved = pd.read_csv(path)
        if {'investigation_id', 'InvestigationJSON', 'GPTReport'} <= set(saved):
            from src.investigation import validate_investigation_ids
            try:
                validate_investigation_ids(saved)
                evidence = packs.set_index('investigation_id')['InvestigationJSON']
                matched = saved['investigation_id'].map(evidence)
                selected_ids = select_investigations(packs, config['genai']['maximum_reports'])['investigation_id'].tolist()
                if (saved.empty or saved['investigation_id'].tolist() == selected_ids) and matched.eq(saved['InvestigationJSON']).all():
                    return
            except ValueError:
                pass
        archive = root / 'audit/report_snapshots'
        archive.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
        shutil.copy2(path, archive / f'gpt_investigation_reports_{stamp}.csv')
        logging.info('Archived historical AI reports: lineage or evidence differs from the current Investigation Pack.')
    empty = packs.head(0).copy()
    empty['GPTReport'] = pd.Series(dtype=str)
    empty.to_csv(path, index=False)


def select_investigations(alerts, maximum_reports):
    """Rank all eligible investigations, bounded by genai.maximum_reports.

    All CombinedAlert investigations remain eligible. No risk values are changed.
    """
    if type(maximum_reports) is not int or maximum_reports < 0:
        raise ValueError('genai.maximum_reports must be a non-negative integer.')
    from src.investigation import validate_investigation_ids
    validate_investigation_ids(alerts)
    if not {'FinalPriority', 'BusinessImpactScore'} <= set(alerts):
        raise ValueError('Report selection requires saved priority and business impact.')
    ranks = alerts['FinalPriority'].map({name: i for i, name in enumerate(PRIORITY_ORDER)})
    scores = pd.to_numeric(alerts['BusinessImpactScore'], errors='coerce')
    if ranks.isna().any() or scores.isna().any() or not scores.map(math.isfinite).all():
        raise ValueError('Report selection requires valid saved priorities and finite scores.')
    return (alerts.assign(_report_priority=ranks, _report_score=scores)
            .sort_values(['_report_priority', '_report_score', 'investigation_id'],
                         ascending=[True, False, True], kind='stable')
            .head(maximum_reports).drop(columns=['_report_priority', '_report_score']).copy())

def run(project_root, config):
    genai = config['genai']
    if not genai['enabled']:
        logging.info('AI reporting skipped: disabled in the Asset Control Pack.')
        return 0
    # Validate prompt even when no credential exists, as in notebook Block 9.
    try:
        prompts = load_prompts(project_root, genai)
        _, _, raw = prompts
    except (FileNotFoundError, ValueError) as error:
        # These are our sanitized template validation messages, not API/secret errors.
        logging.error('AI prompt configuration: %s', error)
        raise
    key = resolve_openai_key(project_root)
    if not key:
        logging.info('AI reporting skipped: no OPENAI_API_KEY in environment or .streamlit/secrets.toml.')
        return 0
    from openai import OpenAI
    try:
        client = OpenAI(api_key=key)
    except Exception:
        logging.warning('AI reporting skipped: OpenAI client could not be initialized.')
        return 0
    alerts = pd.read_csv(project_root / 'data/processed/investigation_pack.csv')
    alerts = select_investigations(alerts, genai['maximum_reports'])
    audit = project_root / 'audit/prompt_snapshots'
    audit.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
    with (audit / f'investigation_{stamp}.yaml').open('xb') as handle:
        handle.write(raw)
    reports = []
    for number, (_, row) in enumerate(alerts.iterrows(), 1):
        logging.info('AI investigation report %s/%s', number, len(alerts))
        try:
            response = client.responses.create(model=genai['model'],
                input=investigation_messages(investigation_evidence(row), prompts))
            reports.append(response.output_text)
        except Exception:
            # The notebook's raw exception text can include credentials/service details.
            # Keep its LLM Error marker without persisting or logging those details.
            reports.append('LLM Error: report generation failed; check AI service access.')
            logging.warning('AI report %s failed; analytical results remain available.', number)
        time.sleep(genai['delay_seconds'])
    alerts['GPTReport'] = reports
    alerts.to_csv(project_root / 'reports/gpt_investigation_reports.csv', index=False)
    return len(alerts)
