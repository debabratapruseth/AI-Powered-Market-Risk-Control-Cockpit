"""Notebook Block 2: data generation. Formulas and CSV handoffs retained."""
import json
import random
import numpy as np
import pandas as pd


def run(project_root, config, as_of=None):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    PROTOTYPE_CONFIG = CONFIG["prototype"]
    SCENARIO_CONFIG = CONFIG["scenarios"]
    INSTRUMENT_FIELD = DATA_CONFIG["instrument_field"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PRICE_FIELD = DATA_CONFIG["price_field"]
    COMPARISON_PRICE_FIELD = DATA_CONFIG["source_field"][DATA_CONFIG["required_sources"][1]]
    PORTFOLIO_FIELD = DATA_CONFIG["portfolio_field"]
    EXPOSURE_FIELD = DATA_CONFIG["exposure_field"]
    VAR_CONTRIBUTION_FIELD = DATA_CONFIG["var_contribution_field"]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 2
    #
    # Generate synthetic datasets for the VaR Control Cockpit
    #
    # Datasets:
    # 1. Market observations
    # 2. VaR scenarios
    # 3. Portfolio exposures
    # 4. Historical alerts
    #
    # Outputs are saved to the local project.
    # In production set up you will source the data from golden sources. For this pilot we will create synthetic data set.
    # ============================================================
    from datetime import datetime
    # -----------------------------------------------------------
    # Configuration
    # -----------------------------------------------------------
    currency_pairs = PROTOTYPE_CONFIG["currency_pairs"]
    vendors = DATA_CONFIG["required_sources"]
    portfolios = [
        "FX Trading",
        "Treasury",
        "Corporate Banking",
        "Private Banking"
    ]
    risk_levels = [
        "High",
        "Medium",
        "Low"
    ]
    # -----------------------------------------------------------
    # Generate hourly timestamps
    # -----------------------------------------------------------
    # Effective sampling frequency is loaded without mutating the active pack.
    timestamps = pd.date_range(
        end=pd.Timestamp.today() if as_of is None else pd.Timestamp(as_of),
        periods=24*PROTOTYPE_CONFIG["days_of_history"],
        freq=PROTOTYPE_CONFIG["sampling_frequency"]
    )
    # -----------------------------------------------------------
    # Base Prices
    # -----------------------------------------------------------
    base_price = {
        "USDSGD":1.35,
        "EURUSD":1.09,
        "GBPUSD":1.28,
        "USDJPY":155,
        "AUDUSD":0.67
    }
    market_rows = []
    # -----------------------------------------------------------
    # Generate Market Prices
    # -----------------------------------------------------------
    for pair in currency_pairs:
        current_price = base_price[pair]
        for ts in timestamps:
            # Small random walk
            current_price *= (
                1 + np.random.normal(0,0.001)
            )
            reuters = current_price
            bloomberg = current_price * (
                1 + np.random.normal(0,0.0003)
            )
            market_rows.append([
                ts,
                pair,
                reuters,
                bloomberg
            ])
    market_df = pd.DataFrame(
        market_rows,
        columns=[
            TIMESTAMP_FIELD,
            INSTRUMENT_FIELD,
            PRICE_FIELD,
            COMPARISON_PRICE_FIELD
        ]
    )
    # -----------------------------------------------------------
    # Inject Stale Prices
    # -----------------------------------------------------------
    stale_index = np.random.choice(
        market_df.index,
        15,
        replace=False
    )
    market_df.loc[
        stale_index,
        PRICE_FIELD
    ] = market_df.loc[
        stale_index-1,
        PRICE_FIELD
    ].values
    market_df["InjectedStale"] = False
    market_df.loc[
        stale_index,
        "InjectedStale"
    ] = True
    # -----------------------------------------------------------
    # Inject Outliers
    # -----------------------------------------------------------
    outlier_index = np.random.choice(
        market_df.index,
        15,
        replace=False
    )
    market_df.loc[
        outlier_index,
        PRICE_FIELD
    ] *= np.random.uniform(
        1.05,
        1.10,
        len(outlier_index)
    )
    market_df["InjectedOutlier"] = False
    market_df.loc[
        outlier_index,
        "InjectedOutlier"
    ] = True
    # -----------------------------------------------------------
    # Generate VaR Scenario Shocks
    # -----------------------------------------------------------
    scenario_df = pd.DataFrame({
        "ScenarioID":
            [f"S{i}" for i in range(1, len(SCENARIO_CONFIG["names"]) + 1)],
        "Scenario":
            SCENARIO_CONFIG["names"],
        "ShockPercent":
            np.random.uniform(
                SCENARIO_CONFIG["shock_percent_min"],
                SCENARIO_CONFIG["shock_percent_max"],
                len(SCENARIO_CONFIG["names"])
            )
    })
    # -----------------------------------------------------------
    # Portfolio Exposure
    # -----------------------------------------------------------
    exposure_rows = []
    for portfolio in portfolios:
        for pair in currency_pairs:
            exposure_rows.append({
                PORTFOLIO_FIELD:portfolio,
                INSTRUMENT_FIELD:pair,
                EXPOSURE_FIELD:
                    np.random.randint(
                        5_000_000,
                        50_000_000
                    ),
                VAR_CONTRIBUTION_FIELD:
                    round(
                        np.random.uniform(
                            1,
                            20
                        ),
                        2
                    ),
                "Criticality":
                    random.choice(
                        risk_levels
                    )
            })
    exposure_df = pd.DataFrame(exposure_rows)
    # -----------------------------------------------------------
    # Historical Alerts
    # -----------------------------------------------------------
    historical_df = pd.DataFrame({
        "AlertID":
            [f"A{i}" for i in range(1,51)],
        INSTRUMENT_FIELD:
            np.random.choice(
                currency_pairs,
                50
            ),
        "AlertType":
            np.random.choice(
                [
                    "Stale",
                    "Outlier",
                    "Missing",
                    "Source Divergence"
                ],
                50
            ),
        "ResolvedAs":
            np.random.choice(
                [
                    "True Issue",
                    "False Positive"
                ],
                50
            ),
        "RootCause":
            np.random.choice(
                [
                    "Vendor Delay",
                    "Market Movement",
                    "Bad Mapping",
                    "Holiday",
                    "Missing Feed"
                ],
                50
            )
    })
    # -----------------------------------------------------------
    # Save datasets
    # -----------------------------------------------------------
    market_df.to_csv(
        PROJECT_ROOT /
        "data/raw/market_data.csv",
        index=False
    )
    scenario_df.to_csv(
        PROJECT_ROOT /
        "data/raw/scenarios.csv",
        index=False
    )
    exposure_df.to_csv(
        PROJECT_ROOT /
        "data/raw/exposures.csv",
        index=False
    )
    historical_df.to_csv(
        PROJECT_ROOT /
        "data/raw/historical_alerts.csv",
        index=False
    )
    # -----------------------------------------------------------
    # Quality Checks
    # -----------------------------------------------------------
    quality = pd.DataFrame({
        "Dataset":[
            "Market Data",
            "Scenario",
            "Exposure",
            "Historical Alerts"
        ],
        "Rows":[
            len(market_df),
            len(scenario_df),
            len(exposure_df),
            len(historical_df)
        ]
    })
    # -----------------------------------------------------------
    # Visualisation
    # -----------------------------------------------------------
    sample_pair = "USDSGD"
    plot_df = market_df[
        market_df[INSTRUMENT_FIELD]==sample_pair
    ]
    # -----------------------------------------------------------
    # Show injected anomalies
    # -----------------------------------------------------------

