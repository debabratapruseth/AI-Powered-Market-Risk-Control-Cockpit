"""Notebook Block 5: anomaly detection. Formulas and CSV handoffs retained."""
import json
import random
import numpy as np
import pandas as pd


def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    ML_CONFIG = CONFIG["ml"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 5
    #
    # AI Statistical Anomaly Detection
    #
    # This block uses Isolation Forest to identify unusual market
    # observations.
    #
    # Unlike rule-based detection, Isolation Forest does not rely
    # on predefined thresholds.
    #
    # Instead, it learns what "normal" market behaviour looks like
    # and identifies observations that appear statistically unusual.
    # ============================================================
    # Dependencies are installed before imports in Block 1; no mid-run upgrades.
    from sklearn.preprocessing import StandardScaler
    from sklearn.ensemble import IsolationForest
    # ------------------------------------------------------------
    # Load rule output
    # ------------------------------------------------------------
    market_df = pd.read_csv(
        PROJECT_ROOT /
        "data/processed/market_data_with_rules.csv",
        parse_dates=[TIMESTAMP_FIELD]
    )
    # ------------------------------------------------------------
    # Features used by AI
    # ------------------------------------------------------------
    ML_FEATURES = ML_CONFIG["features"]
    features = ML_FEATURES
    missing_features = set(ML_FEATURES) - set(market_df.columns)
    if missing_features:
        raise ValueError(f"Missing ML input columns: {sorted(missing_features)}")
    # ------------------------------------------------------------
    # Handle missing values
    # ------------------------------------------------------------
    X = market_df[features].copy()
    X = X.fillna(0)
    # ------------------------------------------------------------
    # Standardise features
    # ------------------------------------------------------------
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    # ------------------------------------------------------------
    # Train Isolation Forest
    # ------------------------------------------------------------
    model = IsolationForest(
        contamination=ML_CONFIG["parameters"]["contamination"],
        random_state=ML_CONFIG["parameters"]["random_state"],
        n_estimators=ML_CONFIG["parameters"]["n_estimators"]
    )
    model.fit(X_scaled)
    # ------------------------------------------------------------
    # Predict anomalies
    # ------------------------------------------------------------
    market_df["AIPrediction"] = model.predict(X_scaled)
    # Convert prediction
    market_df["AIAnomaly"] = np.where(
        market_df["AIPrediction"]==-1,
        True,
        False
    )
    # Raw anomaly score
    market_df["AIScore"] = -model.score_samples(X_scaled)
    # ------------------------------------------------------------
    # Scale score to 0-100
    # ------------------------------------------------------------
    min_score = market_df["AIScore"].min()
    max_score = market_df["AIScore"].max()
    market_df["AISeverityScore"] = (
        (market_df["AIScore"]-min_score)
        /(max_score-min_score)
    )*100
    market_df["AISeverityScore"] = market_df["AISeverityScore"].round(1)
    # ------------------------------------------------------------
    # AI Severity
    # ------------------------------------------------------------
    market_df["AISeverity"] = pd.cut(
        market_df["AISeverityScore"],
        bins=ML_CONFIG["severity_bins"],
        labels=[
            "Low",
            "Medium",
            "High",
            "Critical"
        ],
        include_lowest=True
    )
    # ------------------------------------------------------------
    # Combined Alert
    # ------------------------------------------------------------
    market_df["CombinedAlert"] = np.where(
        (market_df["HasRuleAlert"])
        |
        (market_df["AIAnomaly"]),
        True,
        False
    )
    # ------------------------------------------------------------
    # Explain AI Result
    # ------------------------------------------------------------
    def explain_ai(row):
        reasons=[]
        if abs(row["ZScore"])>ML_CONFIG["explanation_thresholds"]["absolute_z_score"]:
            reasons.append("Extreme Z Score")
        if row["SourceDifferencePct"]>ML_CONFIG["explanation_thresholds"]["source_divergence_pct"]:
            reasons.append("Vendor disagreement")
        if row["FeedLatencySeconds"]>ML_CONFIG["explanation_thresholds"]["maximum_latency_seconds"]:
            reasons.append("High latency")
        if abs(row["PctChange"])>ML_CONFIG["explanation_thresholds"]["large_move_pct"]:
            reasons.append("Large movement")
        if len(reasons)==0:
            reasons.append("Multivariate anomaly")
        return ", ".join(reasons)
    market_df["AIExplanation"] = market_df.apply(
        explain_ai,
        axis=1
    )
    # ------------------------------------------------------------
    # Quality Checks
    # ------------------------------------------------------------
    quality=[]
    quality.append({
        "Check":"Model trained",
        "Passed":True
    })
    quality.append({
        "Check":"AI scores generated",
        "Passed":
        market_df["AISeverityScore"].notna().all()
    })
    quality.append({
        "Check":"Combined Alert created",
        "Passed":
        market_df["CombinedAlert"].notna().all()
    })
    quality_df=pd.DataFrame(quality)
    # ------------------------------------------------------------
    # AI Summary
    # ------------------------------------------------------------
    summary=pd.DataFrame({
        "Metric":[
            "Total Records",
            "Rule Alerts",
            "AI Anomalies",
            "Combined Alerts"
        ],
        "Value":[
            len(market_df),
            market_df["HasRuleAlert"].sum(),
            market_df["AIAnomaly"].sum(),
            market_df["CombinedAlert"].sum()
        ]
    })
    # ------------------------------------------------------------
    # Top AI anomalies
    # ------------------------------------------------------------
    top = market_df[
        market_df["AIAnomaly"]
    ].sort_values(
        "AISeverityScore",
        ascending=False
    ).head(20)
    # ------------------------------------------------------------
    # Visualisation
    # ------------------------------------------------------------
    # Preserve notebook chart sampling: advances the RNG used by later stages.
    market_df.sample(1500)
    # ------------------------------------------------------------
    # Rule vs AI
    # ------------------------------------------------------------
    comparison=pd.DataFrame({
        "Detection":[
            "Rule",
            "AI",
            "Both"
        ],
        "Count":[
            market_df["HasRuleAlert"].sum(),
            market_df["AIAnomaly"].sum(),
            len(
                market_df[
                    (market_df["HasRuleAlert"])
                    &
                    (market_df["AIAnomaly"])
                ]
            )
        ]
    })
    # ------------------------------------------------------------
    # Save output
    # ------------------------------------------------------------
    market_df.to_csv(
    PROJECT_ROOT/
    "data/processed/market_data_with_ai.csv",
    index=False
    )

