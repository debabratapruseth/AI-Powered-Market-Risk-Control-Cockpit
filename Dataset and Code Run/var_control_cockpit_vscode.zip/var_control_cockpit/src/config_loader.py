"""Block 1: unchanged Asset Control Pack validation and configuration lineage."""
import json
import math
import re
import os
from datetime import datetime, timezone
from pathlib import Path
import yaml


def project_root():
    """Resolve independently of the Terminal working directory."""
    return Path(os.environ.get('MARKET_RISK_BASE_PATH') or Path(__file__).resolve().parents[1]).expanduser().resolve()


def parse_generation_as_of(value):
    """Return a fixed Timestamp, or None for the explicit system setting."""
    import pandas as pd
    message = 'Asset Control Pack: data_generation.as_of: must be system or a valid fixed timestamp string'
    if not isinstance(value, str) or not value.strip():
        raise ValueError(message)
    if value.strip().lower() == 'system':
        return None
    # Require a complete date so pandas cannot fill missing date parts from today.
    if not re.match(r'^\d{4}-\d{2}-\d{2}(?:[ Tt]|$)', value.strip()):
        raise ValueError(message + '; fixed values must include YYYY-MM-DD')
    try:
        timestamp = pd.Timestamp(value)
    except (ValueError, TypeError, OverflowError):
        raise ValueError(message) from None
    if pd.isna(timestamp):
        raise ValueError(message)
    return timestamp


def validate_asset_pack(config):
    """Fail early on malformed packs and unsupported baseline capabilities."""
    def fail(path, message):
        raise ValueError(f"Asset Control Pack: {path}: {message}")

    def get(path):
        value = config
        for key in path.split('.'):
            if not isinstance(value, dict) or key not in value:
                fail(path, "required field/section is missing")
            value = value[key]
        return value

    def number(path, minimum=0, integer=False):
        value = get(path)
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            fail(path, "must be a finite number")
        if value < minimum or (integer and not isinstance(value, int)):
            fail(path, f"must be {'an integer' if integer else 'a number'} >= {minimum}")
        return value

    def text(path):
        value = get(path)
        if not isinstance(value, str) or not value.strip():
            fail(path, "must be a non-empty string")
        return value

    def enabled(path):
        if get(path) is not True:
            fail(path, "must be true; this baseline requires the stage/output")

    if not isinstance(config, dict):
        fail('root', 'must be a YAML mapping')
    for section in ['asset_pack', 'data', 'data_generation', 'prototype', 'alert_thresholds', 'feature_engineering',
                    'rule_severity', 'ml', 'detection', 'context', 'confidence',
                    'business_impact', 'action_governance', 'priority', 'scenarios', 'genai', 'output', 'governance']:
        if not isinstance(get(section), dict):
            fail(section, 'must be a mapping')
    parse_generation_as_of(get('data_generation.as_of'))
    enabled('asset_pack.enabled')
    if text('asset_pack.code') != 'FX':
        fail('asset_pack.code', 'only FX is implemented')
    text('asset_pack.name')
    text('asset_pack.version')
    for key in ['instrument_field', 'timestamp_field', 'price_field', 'portfolio_field',
                'exposure_field', 'var_contribution_field']:
        text('data.' + key)
    if get('data.required_sources') != ['Reuters', 'Bloomberg']:
        fail('data.required_sources', 'baseline wide-source layout requires Reuters and Bloomberg in that order')
    for source in get('data.required_sources'):
        text('data.source_field.' + source)
    if get('data.price_field') != get('data.source_field.Reuters'):
        fail('data.price_field', 'must match source_field.Reuters for this baseline')
    mapped = [get('data.' + key) for key in ['instrument_field', 'timestamp_field', 'price_field',
              'portfolio_field', 'exposure_field', 'var_contribution_field']] + [get('data.source_field.Bloomberg')]
    if len(set(mapped)) != len(mapped):
        fail('data', 'mapped column names must be distinct')
    for key in ['stale_price_tolerance_pct', 'large_move_pct', 'absolute_z_score',
                'source_divergence_pct', 'maximum_latency_seconds', 'critical_z_score',
                'critical_source_divergence_pct', 'critical_large_move_pct']:
        number('alert_thresholds.' + key)
    number('alert_thresholds.stale_consecutive_periods', 1, True)
    for normal, critical in [('absolute_z_score', 'critical_z_score'),
                             ('source_divergence_pct', 'critical_source_divergence_pct'),
                             ('large_move_pct', 'critical_large_move_pct')]:
        if get('alert_thresholds.' + critical) < get('alert_thresholds.' + normal):
            fail('alert_thresholds.' + critical, 'must be >= ordinary threshold')
    window = number('feature_engineering.rolling_window', 1, True)
    if number('feature_engineering.minimum_periods', 1, True) > window:
        fail('feature_engineering.minimum_periods', 'cannot exceed rolling_window')
    for key in ['pct_change', 'rolling_mean', 'rolling_volatility', 'z_score', 'source_difference', 'feed_latency']:
        enabled('feature_engineering.calculate.' + key)
    enabled('ml.enabled')
    if get('ml.model') != 'IsolationForest':
        fail('ml.model', 'only IsolationForest is supported')
    # Features are fixed to the existing engine capabilities in this first pack.
    required = ['PctChange', 'ZScore', 'SourceDifferencePct', 'FeedLatencySeconds']
    if get('ml.features') != required:
        fail('ml.features', f'required baseline features/order: {required}')
    contamination = number('ml.parameters.contamination')
    if not 0 < contamination <= 0.5:
        fail('ml.parameters.contamination', 'must be in (0, 0.5], the IsolationForest-supported range')
    number('ml.parameters.n_estimators', 1, True)
    seed = number('ml.parameters.random_state', 0, True)
    if seed > 2**32 - 1:
        fail('ml.parameters.random_state', 'must fit an unsigned 32-bit seed')
    bins = get('ml.severity_bins')
    if not isinstance(bins, list) or len(bins) != 5 or any(type(v) not in (int, float) or not math.isfinite(v) for v in bins):
        fail('ml.severity_bins', 'must contain five finite boundaries')
    if bins[0] != 0 or bins[-1] != 100 or any(a >= b for a, b in zip(bins, bins[1:])):
        fail('ml.severity_bins', 'must strictly increase from 0 to 100')
    for key in ['absolute_z_score', 'source_divergence_pct', 'maximum_latency_seconds', 'large_move_pct']:
        number('ml.explanation_thresholds.' + key)
    if get('detection.strategy') != 'RULE_OR_ML':
        fail('detection.strategy', 'only RULE_OR_ML is implemented')
    enabled('detection.rule_alert_enabled')
    enabled('detection.ml_alert_enabled')
    for key in ['stale', 'large_move', 'z_score', 'source_divergence', 'high_latency']:
        number('rule_severity.weights.' + key)
    for key in ['z_score', 'source_divergence', 'large_move']:
        number('rule_severity.critical_bonus.' + key)
    rule_max = number('rule_severity.maximum_score', 1)
    for prefix, maximum in [('rule_severity.thresholds', rule_max), ('priority', number('business_impact.maximum_score', 1))]:
        values = [number(prefix + '.' + k) for k in ['critical', 'high', 'medium', 'low']]
        if values[0] > maximum or any(a <= b for a, b in zip(values, values[1:])):
            fail(prefix, 'require maximum >= critical > high > medium > low >= 0')
    enabled('context.historical_similarity.enabled')
    enabled('context.peer_analysis.enabled')
    mapping = get('context.historical_similarity.alert_type_mapping')
    if not isinstance(mapping, dict) or not mapping or not all(isinstance(k, str) and isinstance(v, str) for k, v in mapping.items()):
        fail('context.historical_similarity.alert_type_mapping', 'must map alert labels to history labels')
    for key in ['peer_analysis.deviation_threshold', 'vendor_agreement.strong_below',
                'vendor_agreement.moderate_below', 'market_wide_move_threshold']:
        number('context.' + key)
    if get('context.vendor_agreement.strong_below') >= get('context.vendor_agreement.moderate_below'):
        fail('context.vendor_agreement', 'strong_below must be less than moderate_below')
    if get('confidence.scoring_mode') != 'bounded_point_budgets':
        fail('confidence.scoring_mode', 'requires contextual bounded_point_budgets')
    if number('confidence.maximum_score', 1) != 100:
        fail('confidence.maximum_score', 'the cockpit score scale must remain 100')
    keys = ['vendor_disagreement', 'peer_deviation', 'historical_recurrence']
    if set(get('confidence.component_budgets')) != set(keys):
        fail('confidence.component_budgets', 'only vendor, peer and historical budgets are supported')
    if sum(number('confidence.component_budgets.' + key) for key in keys) <= 0:
        fail('confidence.component_budgets', 'at least one budget must be positive')
    number('confidence.historical_count_cap', 1, True)
    if 'weights' in config['confidence'] or 'recommendation_thresholds' in config['context']:
        fail('confidence/context', 'remove obsolete detection confidence weights and recommendation thresholds')
    if get('business_impact.scoring_mode') != 'bounded_point_budgets':
        fail('business_impact.scoring_mode', 'requires bounded_point_budgets; migrate legacy coefficients explicitly')
    budgets = [number('business_impact.component_budgets.' + key) for key in
               ['rule_severity', 'ml_severity', 'confidence', 'exposure', 'var_contribution']]
    if sum(budgets) <= 0:
        fail('business_impact.component_budgets', 'at least one budget must be positive')
    if get('business_impact.maximum_score') != 100:
        fail('business_impact.maximum_score', 'the cockpit score scale must remain 100')
    for key in ['score_upper_bound', 'var_percentage_upper_bound']:
        if number('business_impact.normalization.' + key) <= 0:
            fail('business_impact.normalization.' + key, 'must be positive')
    for key, supported in [('exposure', 'finite_positive_population_max'), ('inactive_detection', 'zero'), ('invalid_numeric', 'zero')]:
        if get('business_impact.normalization.' + key) != supported:
            fail('business_impact.normalization.' + key, 'unsupported normalization policy')
    if number('business_impact.rounding_decimals', 0, True) > 10:
        fail('business_impact.rounding_decimals', 'must not exceed 10')
    if set(config['action_governance']) != {'priority_actions'}:
        fail('action_governance', 'only priority_actions is supported; remove obsolete action-chain settings')
    actions = get('action_governance.priority_actions')
    priorities = ['critical', 'high', 'medium', 'low', 'monitor']
    if not isinstance(actions, dict) or set(actions) != set(priorities):
        fail('action_governance.priority_actions', 'all five priorities must define an action')
    for key in priorities:
        if not isinstance(actions[key], dict) or set(actions[key]) != {'recommendation', 'business_recommendation', 'required_action'}:
            fail('action_governance.priority_actions.' + key, 'requires exactly the three action text fields')
        for field in ['recommendation', 'business_recommendation', 'required_action']:
            text(f'action_governance.priority_actions.{key}.{field}')
    number('prototype.random_seed', 0, True)
    number('prototype.days_of_history', 1, True)
    for key in ['project_name', 'version', 'sampling_frequency', 'audit_sampling_frequency']:
        text('prototype.' + key)
    pairs = get('prototype.currency_pairs')
    if not isinstance(pairs, list) or not pairs or len(set(pairs)) != len(pairs) or not all(isinstance(p, str) for p in pairs):
        fail('prototype.currency_pairs', 'must be a non-empty list of distinct currency pairs')
    names = get('scenarios.names')
    if not isinstance(names, list) or not names or not all(isinstance(v, str) and v for v in names):
        fail('scenarios.names', 'must contain scenario names')
    lower = number('scenarios.shock_percent_min', -float('inf'))
    upper = number('scenarios.shock_percent_max', -float('inf'))
    if lower >= upper:
        fail('scenarios', 'shock_percent_min must be less than shock_percent_max')
    if type(get('genai.enabled')) is not bool:
        fail('genai.enabled', 'must be boolean')
    priorities = get('genai.generate_for')
    if priorities is not None and (not isinstance(priorities, list) or not all(p in ['Critical', 'High', 'Medium', 'Low', 'Monitor'] for p in priorities)):
        fail('genai.generate_for', 'must be null or a list of priority labels')
    number('genai.maximum_reports', 0, True)
    number('genai.delay_seconds')
    text('genai.model')
    text('genai.prompt_file')
    sections = get('genai.required_sections')
    if not isinstance(sections, list) or len(sections) != 6 or not all(isinstance(v, str) and v.strip() for v in sections):
        fail('genai.required_sections', 'must contain six section headings for the shared investigation prompt')
    for key in ['save_rule_alerts', 'save_ml_results', 'save_context_results', 'save_prioritised_alerts', 'save_investigation_pack']:
        enabled('output.' + key)
    text('governance.owner')
    for key in ['approval_required', 'model_validation_required', 'change_reason_required', 'audit_configuration_changes']:
        if type(get('governance.' + key)) is not bool:
            fail('governance.' + key, 'must be boolean policy metadata')


def load_asset_pack(config_path, project_root):
    """Parse once and snapshot the same bytes; never re-read mutable source for audit."""
    config_path, project_root = Path(config_path), Path(project_root)
    if not config_path.is_file():
        raise FileNotFoundError(f"Missing Asset Control Pack: {config_path}. No defaults were invented.")
    raw = config_path.read_bytes()
    config = yaml.safe_load(raw)
    validate_asset_pack(config)
    timestamp = datetime.now(timezone.utc)
    directory = project_root / 'audit/config_snapshots'
    directory.mkdir(parents=True, exist_ok=True)
    # Microseconds plus exclusive creation prevent accidental same-second overwrites.
    stem = f"fx_{timestamp.strftime('%Y%m%d_%H%M%S_%f')}"
    snapshot = directory / f'{stem}.yaml'
    with snapshot.open('xb') as file:
        file.write(raw)
    metadata = {
        'asset_pack': config['asset_pack']['code'],
        'asset_pack_version': config['asset_pack']['version'],
        'execution_timestamp': timestamp.isoformat(),
        'configuration_file': str(config_path),
        'ml_model': config['ml']['model'],
    }
    with (directory / f'{stem}.json').open('x', encoding='utf-8') as file:
        json.dump(metadata, file, indent=2)
    return config, snapshot

