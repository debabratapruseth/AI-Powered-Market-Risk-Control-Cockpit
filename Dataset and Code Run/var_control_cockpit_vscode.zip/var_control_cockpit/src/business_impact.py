"""Block 7: bounded scenario-independent prioritization and final action governance."""
import json
import random
import numpy as np
import pandas as pd



COMPONENT_COLUMNS = ['RuleImpactComponent', 'AIImpactComponent', 'ConfidenceImpactComponent',
                     'ExposureImpactComponent', 'RiskImpactComponent']
def priority_action(priority, config):
    """Final Priority is the sole action driver."""
    return config['action_governance']['priority_actions'][priority.lower()]


def bounded_impact_components(frame, config):
    """Prototype point-budget correction, not calibrated/bank-approved weights.

    YAML supplies component budgets, input bounds, output scale and policies.
    Each bounded input is weighted by its budget / total budget. The defaults
    preserve the prior corrected 25/20/20/20/4 allocation exactly.

    VaRContribution is synthetic uniform(1,20) per portfolio/risk-factor in
    data_generation.py, merged from exposures.csv in enrichment.py BEFORE any
    scenario assignment. It is independent of the assigned illustrative scenario.
    Never read scenario, shock, P&L or scenario VaR fields here.

    Each numeric input is finite, nonnegative and bounded before weighting.
    Missing/invalid/nonfinite values contribute zero; missing detector flags
    never activate evidence. Exposure uses the maximum finite positive exposure
    in the full input population; zero/all-invalid exposure contributes zero.
    Stored components are unrounded points; their sum rounded to one decimal
    reconciles to BusinessImpactScore. Upstream scores are never overwritten.
    """
    def finite(field):
        return pd.to_numeric(frame[field], errors='coerce').replace([np.inf, -np.inf], np.nan).fillna(0).clip(lower=0)

    def active(field):
        return frame[field].astype('string').str.strip().str.lower().isin(['true', '1'])

    settings = config['business_impact']
    weights = settings['component_budgets']
    bounds = settings['normalization']
    score_bound = bounds['score_upper_bound']
    var_bound = bounds['var_percentage_upper_bound']
    budgets = np.array([weights[key] for key in ['rule_severity', 'ml_severity', 'confidence', 'exposure', 'var_contribution']], dtype=float)
    if not np.isfinite(budgets).all() or (budgets < 0).any() or budgets.sum() <= 0:
        raise ValueError('Business impact point budgets must be finite, nonnegative and have a positive total.')
    exposure = finite(config['data']['exposure_field'])
    maximum = exposure.max()
    exposure_ratio = exposure / maximum if pd.notna(maximum) and maximum > 0 else exposure * 0
    normalized = pd.DataFrame({
        'RuleImpactComponent': finite('RuleSeverityScore').clip(upper=score_bound) / score_bound * active('HasRuleAlert'),
        'AIImpactComponent': finite('AISeverityScore').clip(upper=score_bound) / score_bound * active('AIAnomaly'),
        'ConfidenceImpactComponent': finite('ConfidenceScore').clip(upper=score_bound) / score_bound,
        'ExposureImpactComponent': exposure_ratio.clip(0, 1),
        'RiskImpactComponent': finite(config['data']['var_contribution_field']).clip(upper=var_bound) / var_bound,
    }, index=frame.index)
    return normalized.mul(settings['maximum_score'] * budgets / budgets.sum(), axis='columns')


def apply_business_priority(frame, config):
    result = frame.copy()
    components = bounded_impact_components(result, config)
    result[COMPONENT_COLUMNS] = components
    result['BusinessImpactScore'] = components.sum(axis=1).clip(0, config['business_impact']['maximum_score']).round(config['business_impact']['rounding_decimals'])
    thresholds = config['priority']
    labels = ['Critical', 'High', 'Medium', 'Low']
    result['FinalPriority'] = np.select([result.BusinessImpactScore.ge(thresholds[label.lower()]) for label in labels], labels, default='Monitor')
    # Discard obsolete action-chain fields if a prior output is replayed.
    result = result.drop(columns=['ContextRecommendation', 'FinalAction'], errors='ignore')
    policies = result.FinalPriority.map(lambda priority: priority_action(priority, config))
    result['Recommendation'] = policies.map(lambda policy: policy['recommendation'])
    result['BusinessRecommendation'] = policies.map(lambda policy: policy['business_recommendation'])
    return result

def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PRICE_FIELD = DATA_CONFIG["price_field"]
    EXPOSURE_FIELD = DATA_CONFIG["exposure_field"]
    VAR_CONTRIBUTION_FIELD = DATA_CONFIG["var_contribution_field"]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 7
    #
    # VaR IMPACT & BUSINESS PRIORITISATION
    #
    # PURPOSE
    # -------
    # Convert technical alerts into business risk by estimating:
    #
    # • Shocked Market Price
    # • Estimated P&L Impact
    # • VaR Impact
    # • Business Impact Score
    # • Final Alert Priority
    #
    # Output:
    # market_data_prioritised.csv
    # ============================================================
    # ----------------------------------------------------------
    # Load Context Output
    # ----------------------------------------------------------
    market_df = pd.read_csv(
        PROJECT_ROOT /
        "data/processed/market_data_with_context.csv",
        parse_dates=[TIMESTAMP_FIELD]
    )
    scenario_df = pd.read_csv(
        PROJECT_ROOT /
        "data/raw/scenarios.csv"
    )
    # ----------------------------------------------------------
    # Assign Scenario
    # ----------------------------------------------------------
    #
    # Prototype behaviour:
    # Scenario assignment is synthetic for demonstration purposes.
    # A production implementation would consume approved market-risk
    # scenarios and outputs from the bank's risk engine.
    market_df["ScenarioID"] = np.random.choice(
        scenario_df["ScenarioID"],
        len(market_df)
    )
    market_df = market_df.merge(
        scenario_df,
        on="ScenarioID",
        how="left"
    )
    # ----------------------------------------------------------
    # Shocked Market Price
    # ----------------------------------------------------------
    market_df["ShockedPrice"] = (
        market_df[PRICE_FIELD]
        *
        (
            1 +
            market_df["ShockPercent"]/100
        )
    )
    # ----------------------------------------------------------
    # Estimated P&L
    # ----------------------------------------------------------
    #
    # Simple approximation:
    #
    # PnL = Exposure × Price Change %
    market_df["EstimatedPnL"] = (
        market_df[EXPOSURE_FIELD]
        *
        (
            market_df["ShockedPrice"]
            -
            market_df[PRICE_FIELD]
        )
        /
        market_df[PRICE_FIELD]
    )
    market_df["EstimatedPnL"] = (
        market_df["EstimatedPnL"]
        .round(2)
    )
    # ----------------------------------------------------------
    # Estimated VaR Impact
    # ----------------------------------------------------------
    market_df["EstimatedVaRImpact"] = (
        abs(
            market_df["EstimatedPnL"]
        )
        *
        market_df[VAR_CONTRIBUTION_FIELD]
        /100
    )
    # ----------------------------------------------------------
    # Business Impact Score
    # ----------------------------------------------------------
    market_df = apply_business_priority(market_df, config)
    # ----------------------------------------------------------
    # Executive Dashboard
    # ----------------------------------------------------------
    summary = pd.DataFrame({
        "Metric":[
            "Total Alerts",
            "Critical",
            "High",
            "Medium",
            "Low",
            "Average Estimated P&L",
            "Average Business Score"
        ],
        "Value":[
            len(market_df),
            (market_df["FinalPriority"]=="Critical").sum(),
            (market_df["FinalPriority"]=="High").sum(),
            (market_df["FinalPriority"]=="Medium").sum(),
            (market_df["FinalPriority"]=="Low").sum(),
            round(
                market_df["EstimatedPnL"].mean(),
                2
            ),
            round(
                market_df["BusinessImpactScore"].mean(),
                1
            )
        ]
    })
    # ----------------------------------------------------------
    # Top Business Risks
    # ----------------------------------------------------------
    top = (
        market_df
        .sort_values(
            "BusinessImpactScore",
            ascending=False
        )
        .head(20)
    )
    # ----------------------------------------------------------
    # Priority Distribution
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # P&L vs Score
    # ----------------------------------------------------------
    # Preserve notebook chart sampling: advances the RNG used by later stages.
    market_df.sample(1500)
    # ----------------------------------------------------------
    # Save
    # ----------------------------------------------------------
    market_df.to_csv(
        PROJECT_ROOT /
        "data/processed/market_data_prioritised.csv",
        index=False
    )

