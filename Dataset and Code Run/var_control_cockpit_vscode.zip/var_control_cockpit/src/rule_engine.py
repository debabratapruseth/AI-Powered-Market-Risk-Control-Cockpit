"""Notebook Block 4: rule engine. Formulas and CSV handoffs retained."""
import json
import random
import numpy as np
import pandas as pd


def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    ALERT_THRESHOLDS = CONFIG["alert_thresholds"]
    DATA_CONFIG = CONFIG["data"]
    PROTOTYPE_CONFIG = CONFIG["prototype"]
    RULE_SEVERITY_CONFIG = CONFIG["rule_severity"]
    INSTRUMENT_FIELD = DATA_CONFIG["instrument_field"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PRICE_FIELD = DATA_CONFIG["price_field"]
    COMPARISON_PRICE_FIELD = DATA_CONFIG["source_field"][DATA_CONFIG["required_sources"][1]]
    PORTFOLIO_FIELD = DATA_CONFIG["portfolio_field"]
    RANDOM_SEED = PROTOTYPE_CONFIG["random_seed"]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 4
    #
    # STALE AND OUTLIER ALERT RULE ENGINE
    #
    # PURPOSE
    # -------
    # 1. Load the enriched market dataset.
    # 2. Apply transparent market-data quality rules.
    # 3. Identify stale, outlier, divergent, and delayed prices.
    # 4. Assign alert severity.
    # 5. Produce alert-level and portfolio-level outputs.
    # 6. Validate the alert engine against injected anomalies.
    # 7. Save the results to the local project.
    #
    # IMPORTANT DESIGN PRINCIPLE
    # --------------------------
    # This stage uses deterministic and explainable rules.
    # Machine learning will be added in the next block as a
    # complementary anomaly signal.
    # ============================================================
    # ------------------------------------------------------------
    # STEP 1: Load enriched market data
    # ------------------------------------------------------------
    ENRICHED_DATA_FILE = (
        PROJECT_ROOT
        / "data/processed/enriched_market_data.csv"
    )
    if not ENRICHED_DATA_FILE.exists():
        raise FileNotFoundError(
            "The enriched dataset was not found. "
            "Please run Block 3 before running Block 4."
        )
    alerts_df = pd.read_csv(
        ENRICHED_DATA_FILE,
        parse_dates=[TIMESTAMP_FIELD]
    )
    # ------------------------------------------------------------
    # STEP 2: Define configurable alert thresholds
    # ------------------------------------------------------------
    # These thresholds are illustrative for the hackathon.
    # In production, they would be calibrated by:
    #
    # - asset class;
    # - currency pair;
    # - market session;
    # - historical volatility;
    # - control policy;
    # - risk appetite.
    # ALERT_THRESHOLDS is loaded and validated in Block 1.
    # ------------------------------------------------------------
    # STEP 3: Correct data ordering
    # ------------------------------------------------------------
    # Block 3 joined each market observation to multiple portfolios.
    # Therefore, the same price observation can appear several times.
    #
    # To calculate stale runs correctly, we first calculate them on
    # the unique market observation level and then merge the result
    # back to the portfolio-level dataset.
    alerts_df = alerts_df.sort_values(
        [
            INSTRUMENT_FIELD,
            TIMESTAMP_FIELD,
            PORTFOLIO_FIELD
        ]
    ).reset_index(drop=True)
    observation_columns = [
        TIMESTAMP_FIELD,
        INSTRUMENT_FIELD,
        PRICE_FIELD,
        COMPARISON_PRICE_FIELD,
        "InjectedStale",
        "InjectedOutlier",
        "PreviousPrice",
        "PctChange",
        "RollingMean",
        "RollingStd",
        "ZScore",
        "SourceDifference",
        "SourceDifferencePct",
        "FeedLatencySeconds",
        "MarketOpen",
        "MarketSession"
    ]
    observation_df = (
        alerts_df[observation_columns]
        .drop_duplicates(
            subset=[TIMESTAMP_FIELD, INSTRUMENT_FIELD]
        )
        .sort_values(
            [INSTRUMENT_FIELD, TIMESTAMP_FIELD]
        )
        .reset_index(drop=True)
    )
    # ------------------------------------------------------------
    # STEP 4: Calculate stale-price indicators
    # ------------------------------------------------------------
    # A single unchanged price may be legitimate.
    # A sequence of unchanged prices is more suspicious.
    #
    # We calculate:
    # - relative change from the previous observation;
    # - whether the current observation is unchanged;
    # - length of the current unchanged-price sequence.
    observation_df["AbsolutePctChange"] = (
        observation_df["PctChange"].abs()
    )
    observation_df["PriceUnchanged"] = (
        observation_df["AbsolutePctChange"]
        <= ALERT_THRESHOLDS["stale_price_tolerance_pct"]
    )
    def calculate_consecutive_true_count(series):
        """
        Count consecutive True values.
        Example
        -------
        False, True, True, False, True
        becomes
        0, 1, 2, 0, 1
        """
        group_number = (~series).cumsum()
        return (
            series
            .groupby(group_number)
            .cumsum()
            .astype(int)
        )
    observation_df["ConsecutiveUnchangedPeriods"] = (
        observation_df
        .groupby(INSTRUMENT_FIELD)["PriceUnchanged"]
        .transform(calculate_consecutive_true_count)
    )
    observation_df["Rule_Stale"] = (
        observation_df["ConsecutiveUnchangedPeriods"]
        >= ALERT_THRESHOLDS["stale_consecutive_periods"]
    )
    # ------------------------------------------------------------
    # STEP 5: Apply outlier and control rules
    # ------------------------------------------------------------
    # Large movement rule
    observation_df["Rule_LargeMove"] = (
        observation_df["AbsolutePctChange"]
        >= ALERT_THRESHOLDS["large_move_pct"]
    )
    # Statistical outlier rule
    observation_df["Rule_ZScoreOutlier"] = (
        observation_df["ZScore"].abs()
        >= ALERT_THRESHOLDS["absolute_z_score"]
    )
    # Cross-vendor source divergence
    observation_df["Rule_SourceDivergence"] = (
        observation_df["SourceDifferencePct"]
        >= ALERT_THRESHOLDS["source_divergence_pct"]
    )
    # Source latency rule
    observation_df["Rule_HighLatency"] = (
        observation_df["FeedLatencySeconds"]
        > ALERT_THRESHOLDS["maximum_latency_seconds"]
    )
    # Market closed indicator
    # This is context rather than an alert by itself.
    observation_df["Context_MarketClosed"] = (
        ~observation_df["MarketOpen"].astype(bool)
    )
    # ------------------------------------------------------------
    # STEP 6: Count triggered rules
    # ------------------------------------------------------------
    RULE_COLUMNS = [
        "Rule_Stale",
        "Rule_LargeMove",
        "Rule_ZScoreOutlier",
        "Rule_SourceDivergence",
        "Rule_HighLatency"
    ]
    observation_df["TriggeredRuleCount"] = (
        observation_df[RULE_COLUMNS]
        .sum(axis=1)
    )
    observation_df["HasRuleAlert"] = (
        observation_df["TriggeredRuleCount"] > 0
    )
    # ------------------------------------------------------------
    # STEP 7: Create human-readable alert types
    # ------------------------------------------------------------
    RULE_LABELS = {
        "Rule_Stale": "Stale Price",
        "Rule_LargeMove": "Large Price Movement",
        "Rule_ZScoreOutlier": "Statistical Outlier",
        "Rule_SourceDivergence": "Source Divergence",
        "Rule_HighLatency": "High Feed Latency"
    }
    def build_alert_types(row):
        """
        Return a readable list of all rules triggered by one
        market observation.
        """
        triggered_alerts = [
            label
            for column, label in RULE_LABELS.items()
            if bool(row[column])
        ]
        if not triggered_alerts:
            return "No Alert"
        return " | ".join(triggered_alerts)
    observation_df["AlertTypes"] = observation_df.apply(
        build_alert_types,
        axis=1
    )
    # ------------------------------------------------------------
    # STEP 8: Calculate rule severity score
    # ------------------------------------------------------------
    # The rule score combines the number and seriousness of issues.
    #
    # This score is deliberately transparent:
    #
    # Stale price               = 25 points
    # Large price movement      = 25 points
    # Statistical outlier       = 25 points
    # Source divergence         = 30 points
    # High source latency       = 15 points
    #
    # Multiple simultaneous problems create a higher score.
    observation_df["RuleSeverityScore"] = (
        observation_df["Rule_Stale"].astype(int) * RULE_SEVERITY_CONFIG["weights"]["stale"]
        + observation_df["Rule_LargeMove"].astype(int) * RULE_SEVERITY_CONFIG["weights"]["large_move"]
        + observation_df["Rule_ZScoreOutlier"].astype(int) * RULE_SEVERITY_CONFIG["weights"]["z_score"]
        + observation_df["Rule_SourceDivergence"].astype(int) * RULE_SEVERITY_CONFIG["weights"]["source_divergence"]
        + observation_df["Rule_HighLatency"].astype(int) * RULE_SEVERITY_CONFIG["weights"]["high_latency"]
    )
    # Add extra weight for extreme conditions
    observation_df["RuleSeverityScore"] += np.where(
        observation_df["ZScore"].abs()
        >= ALERT_THRESHOLDS["critical_z_score"],
        RULE_SEVERITY_CONFIG["critical_bonus"]["z_score"],
        0
    )
    observation_df["RuleSeverityScore"] += np.where(
        observation_df["SourceDifferencePct"]
        >= ALERT_THRESHOLDS["critical_source_divergence_pct"],
        RULE_SEVERITY_CONFIG["critical_bonus"]["source_divergence"],
        0
    )
    observation_df["RuleSeverityScore"] += np.where(
        observation_df["AbsolutePctChange"]
        >= ALERT_THRESHOLDS["critical_large_move_pct"],
        RULE_SEVERITY_CONFIG["critical_bonus"]["large_move"],
        0
    )
    # Limit the score to 100 for easier interpretation
    observation_df["RuleSeverityScore"] = (
        observation_df["RuleSeverityScore"]
        .clip(lower=0, upper=RULE_SEVERITY_CONFIG["maximum_score"])
    )
    # ------------------------------------------------------------
    # STEP 9: Assign preliminary severity
    # ------------------------------------------------------------
    # This is the control-rule severity only.
    #
    # Scenario, VaR, exposure and P&L impact will be added later
    # before calculating the final business priority.
    severity_conditions = [
        observation_df["RuleSeverityScore"] >= RULE_SEVERITY_CONFIG["thresholds"]["critical"],
        observation_df["RuleSeverityScore"] >= RULE_SEVERITY_CONFIG["thresholds"]["high"],
        observation_df["RuleSeverityScore"] >= RULE_SEVERITY_CONFIG["thresholds"]["medium"],
        observation_df["RuleSeverityScore"] > RULE_SEVERITY_CONFIG["thresholds"]["low"]
    ]
    severity_labels = [
        "Critical",
        "High",
        "Medium",
        "Low"
    ]
    observation_df["RuleSeverity"] = np.select(
        severity_conditions,
        severity_labels,
        default="No Alert"
    )
    # ------------------------------------------------------------
    # STEP 10: Create unique observation-level alert IDs
    # ------------------------------------------------------------
    observation_df["ObservationID"] = (
        observation_df[INSTRUMENT_FIELD]
        + "_"
        + observation_df[TIMESTAMP_FIELD].dt.strftime(
            "%Y%m%d_%H%M%S"
        )
    )
    observation_df["AlertID"] = np.where(
        observation_df["HasRuleAlert"],
        "RULE_"
        + observation_df["ObservationID"],
        None
    )
    # ------------------------------------------------------------
    # STEP 11: Add alert evidence
    # ------------------------------------------------------------
    # Evidence fields allow reviewers and analysts to see exactly
    # why the control triggered.
    def build_rule_evidence(row):
        """
        Create a concise evidence statement for each alert.
        """
        evidence = []
        if row["Rule_Stale"]:
            evidence.append(
                "Price unchanged for "
                f"{int(row['ConsecutiveUnchangedPeriods'])} periods"
            )
        if row["Rule_LargeMove"]:
            evidence.append(
                "Absolute movement "
                f"{row['AbsolutePctChange']:.2%}"
            )
        if row["Rule_ZScoreOutlier"]:
            evidence.append(
                f"Z-score {row['ZScore']:.2f}"
            )
        if row["Rule_SourceDivergence"]:
            evidence.append(
                "Reuters-Bloomberg divergence "
                f"{row['SourceDifferencePct']:.2%}"
            )
        if row["Rule_HighLatency"]:
            evidence.append(
                "Feed latency "
                f"{int(row['FeedLatencySeconds'])} seconds"
            )
        if row["Context_MarketClosed"]:
            evidence.append(
                "Observation occurred while market was closed"
            )
        if not evidence:
            return "No control exception"
        return "; ".join(evidence)
    observation_df["RuleEvidence"] = observation_df.apply(
        build_rule_evidence,
        axis=1
    )
    # ------------------------------------------------------------
    # STEP 12: Merge rule results back to portfolio-level records
    # ------------------------------------------------------------
    rule_output_columns = [
        TIMESTAMP_FIELD,
        INSTRUMENT_FIELD,
        "ObservationID",
        "AlertID",
        "AbsolutePctChange",
        "PriceUnchanged",
        "ConsecutiveUnchangedPeriods",
        "Rule_Stale",
        "Rule_LargeMove",
        "Rule_ZScoreOutlier",
        "Rule_SourceDivergence",
        "Rule_HighLatency",
        "Context_MarketClosed",
        "TriggeredRuleCount",
        "HasRuleAlert",
        "AlertTypes",
        "RuleSeverityScore",
        "RuleSeverity",
        "RuleEvidence"
    ]
    alerts_df = alerts_df.merge(
        observation_df[rule_output_columns],
        on=[TIMESTAMP_FIELD, INSTRUMENT_FIELD],
        how="left"
    )
    # ------------------------------------------------------------
    # STEP 13: Create active alert datasets
    # ------------------------------------------------------------
    observation_alerts_df = observation_df[
        observation_df["HasRuleAlert"]
    ].copy()
    portfolio_alerts_df = alerts_df[
        alerts_df["HasRuleAlert"]
    ].copy()
    # ------------------------------------------------------------
    # STEP 14: Rule-engine quality gates
    # ------------------------------------------------------------
    quality_checks = []
    def add_quality_check(
        check_name,
        actual_value,
        expected_condition,
        passed,
        explanation
    ):
        """
        Add one reviewable quality-gate result.
        """
        quality_checks.append(
            {
                "Quality Check": check_name,
                "Actual Value": actual_value,
                "Expected Condition": expected_condition,
                "Passed": bool(passed),
                "Explanation": explanation
            }
        )
    # Gate 1: All rule columns must exist
    missing_rule_columns = [
        column
        for column in RULE_COLUMNS
        if column not in observation_df.columns
    ]
    add_quality_check(
        check_name="All alert rules created",
        actual_value=len(missing_rule_columns),
        expected_condition="0 missing rule columns",
        passed=len(missing_rule_columns) == 0,
        explanation=(
            "Confirms that all planned control checks were executed."
        )
    )
    # Gate 2: Every alert must have evidence
    alerts_without_evidence = (
        observation_alerts_df["RuleEvidence"]
        .isna()
        .sum()
    )
    add_quality_check(
        check_name="Alert evidence coverage",
        actual_value=alerts_without_evidence,
        expected_condition="0 alerts without evidence",
        passed=alerts_without_evidence == 0,
        explanation=(
            "Every generated alert must explain why it triggered."
        )
    )
    # Gate 3: Every alert must have severity
    alerts_without_severity = (
        observation_alerts_df["RuleSeverity"]
        .isin(["No Alert", ""])
        .sum()
    )
    add_quality_check(
        check_name="Alert severity coverage",
        actual_value=alerts_without_severity,
        expected_condition="0 alerts without severity",
        passed=alerts_without_severity == 0,
        explanation=(
            "Every alert must receive a preliminary control severity."
        )
    )
    # Gate 4: Injected outlier detection recall
    injected_outliers = observation_df[
        observation_df["InjectedOutlier"].astype(bool)
    ]
    detected_injected_outliers = injected_outliers[
        injected_outliers[
            [
                "Rule_LargeMove",
                "Rule_ZScoreOutlier",
                "Rule_SourceDivergence"
            ]
        ].any(axis=1)
    ]
    outlier_recall = (
        len(detected_injected_outliers)
        / len(injected_outliers)
        if len(injected_outliers) > 0
        else 0
    )
    add_quality_check(
        check_name="Injected outlier detection recall",
        actual_value=f"{outlier_recall:.1%}",
        expected_condition="At least 75%",
        passed=outlier_recall >= 0.75,
        explanation=(
            "Measures whether the rule engine detects the synthetic "
            "outliers deliberately inserted in Block 2."
        )
    )
    # Gate 5: Any injected unchanged observation recognised
    # Note: Block 2 injected isolated one-period repeats.
    # Our formal stale rule requires two consecutive unchanged periods.
    # Therefore, we separately verify recognition of unchanged prices.
    injected_stale_rows = observation_df[
        observation_df["InjectedStale"].astype(bool)
    ]
    recognised_unchanged = injected_stale_rows[
        injected_stale_rows["PriceUnchanged"]
    ]
    unchanged_recognition_rate = (
        len(recognised_unchanged)
        / len(injected_stale_rows)
        if len(injected_stale_rows) > 0
        else 0
    )
    add_quality_check(
        check_name="Injected unchanged-price recognition",
        actual_value=f"{unchanged_recognition_rate:.1%}",
        expected_condition="At least 75%",
        passed=unchanged_recognition_rate >= 0.75,
        explanation=(
            "Confirms that deliberately repeated prices are recognised. "
            "The formal stale alert requires a longer sequence."
        )
    )
    # Gate 6: No duplicate observation alert IDs
    duplicate_alert_ids = (
        observation_alerts_df["AlertID"]
        .duplicated()
        .sum()
    )
    add_quality_check(
        check_name="Unique observation alert IDs",
        actual_value=int(duplicate_alert_ids),
        expected_condition="0 duplicate alert IDs",
        passed=duplicate_alert_ids == 0,
        explanation=(
            "Each market observation alert must have a unique identifier."
        )
    )
    quality_df = pd.DataFrame(quality_checks)
    # Stop only if structural controls fail.
    # Detection-recall quality checks remain visible for model tuning.
    critical_check_names = [
        "All alert rules created",
        "Alert evidence coverage",
        "Alert severity coverage",
        "Unique observation alert IDs"
    ]
    critical_failures = quality_df[
        quality_df["Quality Check"].isin(
            critical_check_names
        )
        & (~quality_df["Passed"])
    ]
    if not critical_failures.empty:
        raise RuntimeError(
            "Critical alert-engine quality checks failed: "
            + ", ".join(
                critical_failures["Quality Check"].tolist()
            )
        )
    # ------------------------------------------------------------
    # STEP 15: Alert summary by rule
    # ------------------------------------------------------------
    rule_summary = pd.DataFrame(
        {
            "Alert Rule": [
                RULE_LABELS[column]
                for column in RULE_COLUMNS
            ],
            "Triggered Observations": [
                int(observation_df[column].sum())
                for column in RULE_COLUMNS
            ]
        }
    ).sort_values(
        "Triggered Observations",
        ascending=False
    )
    # ------------------------------------------------------------
    # STEP 16: Alert summary by severity
    # ------------------------------------------------------------
    severity_order = [
        "Critical",
        "High",
        "Medium",
        "Low"
    ]
    severity_summary = (
        observation_alerts_df["RuleSeverity"]
        .value_counts()
        .reindex(
            severity_order,
            fill_value=0
        )
        .rename_axis("Severity")
        .reset_index(name="Alert Count")
    )
    # ------------------------------------------------------------
    # STEP 17: Alert summary by risk factor
    # ------------------------------------------------------------
    risk_factor_summary = (
        observation_alerts_df
        .groupby(INSTRUMENT_FIELD)
        .agg(
            AlertCount=("AlertID", "count"),
            MaximumSeverityScore=(
                "RuleSeverityScore",
                "max"
            ),
            AverageZScore=(
                "ZScore",
                lambda values: values.abs().mean()
            ),
            MaximumSourceDivergence=(
                "SourceDifferencePct",
                "max"
            )
        )
        .reset_index()
        .sort_values(
            "AlertCount",
            ascending=False
        )
    )
    # ------------------------------------------------------------
    # STEP 18: Visualisation — alerts by rule
    # ------------------------------------------------------------
    # ------------------------------------------------------------
    # STEP 19: Visualisation — alerts by severity
    # ------------------------------------------------------------
    # ------------------------------------------------------------
    # STEP 20: Visualisation — alert timeline
    # ------------------------------------------------------------
    timeline_df = (
        observation_alerts_df
        .groupby(
            [
                pd.Grouper(
                    key=TIMESTAMP_FIELD,
                    freq="1D"
                ),
                "RuleSeverity"
            ]
        )
        .size()
        .reset_index(name="AlertCount")
    )
    # ------------------------------------------------------------
    # STEP 21: Visualisation — outlier evidence
    # ------------------------------------------------------------
    # This scatter plot helps reviewers see how the rules behave.
    #
    # Points with high Z-score or high cross-vendor divergence
    # should be visually distinct from ordinary observations.
    plot_sample_size = min(
        2_000,
        len(observation_df)
    )
    outlier_plot_df = observation_df.sample(
        n=plot_sample_size,
        random_state=RANDOM_SEED
    ).copy()
    # ------------------------------------------------------------
    # STEP 22: Display highest-severity alert examples
    # ------------------------------------------------------------
    top_alert_columns = [
        "AlertID",
        TIMESTAMP_FIELD,
        INSTRUMENT_FIELD,
        PRICE_FIELD,
        COMPARISON_PRICE_FIELD,
        "PctChange",
        "ZScore",
        "SourceDifferencePct",
        "FeedLatencySeconds",
        "AlertTypes",
        "RuleSeverityScore",
        "RuleSeverity",
        "RuleEvidence"
    ]
    top_alerts = (
        observation_alerts_df[
            top_alert_columns
        ]
        .sort_values(
            [
                "RuleSeverityScore",
                TIMESTAMP_FIELD
            ],
            ascending=[
                False,
                False
            ]
        )
        .head(15)
    )
    # ------------------------------------------------------------
    # STEP 23: Save outputs to the local project
    # ------------------------------------------------------------
    OBSERVATION_ALERT_FILE = (
        PROJECT_ROOT
        / "data/processed/rule_observation_alerts.csv"
    )
    PORTFOLIO_ALERT_FILE = (
        PROJECT_ROOT
        / "data/processed/rule_portfolio_alerts.csv"
    )
    FULL_RULE_OUTPUT_FILE = (
        PROJECT_ROOT
        / "data/processed/market_data_with_rules.csv"
    )
    QUALITY_REPORT_FILE = (
        PROJECT_ROOT
        / "reports/block4_rule_quality_checks.csv"
    )
    RULE_SUMMARY_FILE = (
        PROJECT_ROOT
        / "reports/block4_rule_summary.csv"
    )
    observation_alerts_df.to_csv(
        OBSERVATION_ALERT_FILE,
        index=False
    )
    portfolio_alerts_df.to_csv(
        PORTFOLIO_ALERT_FILE,
        index=False
    )
    alerts_df.to_csv(
        FULL_RULE_OUTPUT_FILE,
        index=False
    )
    quality_df.to_csv(
        QUALITY_REPORT_FILE,
        index=False
    )
    rule_summary.to_csv(
        RULE_SUMMARY_FILE,
        index=False
    )
    # ------------------------------------------------------------
    # STEP 24: Final output summary
    # ------------------------------------------------------------
    total_observations = len(observation_df)
    total_alerts = len(observation_alerts_df)
    alert_rate = (
        total_alerts / total_observations
        if total_observations > 0
        else 0
    )

