"""Notebook Block 3: enrichment. Formulas and CSV handoffs retained."""
import json
import random
import numpy as np
import pandas as pd


def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    FEATURE_CONFIG = CONFIG["feature_engineering"]
    INSTRUMENT_FIELD = DATA_CONFIG["instrument_field"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PRICE_FIELD = DATA_CONFIG["price_field"]
    COMPARISON_PRICE_FIELD = DATA_CONFIG["source_field"][DATA_CONFIG["required_sources"][1]]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 3
    #
    # DATA VALIDATION & ENRICHMENT
    #
    # Purpose:
    # 1. Load all generated datasets
    # 2. Validate data quality
    # 3. Create derived features
    # 4. Simulate latency & market status
    # 5. Save enriched dataset
    # ============================================================
    # ----------------------------------------------------------
    # Load datasets
    # ----------------------------------------------------------
    market_df = pd.read_csv(
        PROJECT_ROOT / "data/raw/market_data.csv",
        parse_dates=[TIMESTAMP_FIELD]
    )
    scenario_df = pd.read_csv(
        PROJECT_ROOT / "data/raw/scenarios.csv"
    )
    exposure_df = pd.read_csv(
        PROJECT_ROOT / "data/raw/exposures.csv"
    )
    historical_df = pd.read_csv(
        PROJECT_ROOT / "data/raw/historical_alerts.csv"
    )
    # ----------------------------------------------------------
    # Dataset Overview
    # ----------------------------------------------------------
    summary = pd.DataFrame({
        "Dataset":[
            "Market Data",
            "Scenario",
            "Exposure",
            "Historical Alerts"
        ],
        "Rows":[
            len(market_df),
            len(scenario_df),
            len(exposure_df),
            len(historical_df)
        ],
        "Columns":[
            market_df.shape[1],
            scenario_df.shape[1],
            exposure_df.shape[1],
            historical_df.shape[1]
        ]
    })
    # ----------------------------------------------------------
    # Quality Checks
    # ----------------------------------------------------------
    quality = []
    quality.append({
        "Check":"Duplicate Records",
        "Value":market_df.duplicated().sum(),
        "Expected":"0"
    })
    quality.append({
        "Check":"Missing Values",
        "Value":market_df.isna().sum().sum(),
        "Expected":"0"
    })
    quality.append({
        "Check":"Negative Prices",
        "Value":len(
            market_df[
                market_df[PRICE_FIELD]<=0
            ]
        ),
        "Expected":"0"
    })
    quality.append({
        "Check":"Duplicate Timestamp/RiskFactor",
        "Value":market_df.duplicated(
            subset=[TIMESTAMP_FIELD,INSTRUMENT_FIELD]
        ).sum(),
        "Expected":"0"
    })
    quality_df = pd.DataFrame(quality)
    # ----------------------------------------------------------
    # Abort if serious issues found
    # ----------------------------------------------------------
    assert market_df[PRICE_FIELD].min()>0,\
    "Negative price detected"
    # ----------------------------------------------------------
    # Sort data
    # ----------------------------------------------------------
    market_df = market_df.sort_values(
        [
            INSTRUMENT_FIELD,
            TIMESTAMP_FIELD
        ]
    )
    # ----------------------------------------------------------
    # Feature Engineering
    # ----------------------------------------------------------
    # Previous price
    market_df["PreviousPrice"] = (
        market_df
        .groupby(INSTRUMENT_FIELD)
        [PRICE_FIELD]
        .shift(1)
    )
    # Price Change
    market_df["PriceChange"] = (
        market_df[PRICE_FIELD]
        -
        market_df["PreviousPrice"]
    )
    # Percentage Change
    market_df["PctChange"] = (
        market_df["PriceChange"]
        /
        market_df["PreviousPrice"]
    )
    # Rolling Mean
    market_df["RollingMean"] = (
        market_df
        .groupby(INSTRUMENT_FIELD)
        [PRICE_FIELD]
        .transform(
            lambda x:
            x.rolling(
                FEATURE_CONFIG["rolling_window"],
                min_periods=FEATURE_CONFIG["minimum_periods"]
            ).mean()
        )
    )
    # Rolling Std
    market_df["RollingStd"] = (
        market_df
        .groupby(INSTRUMENT_FIELD)
        [PRICE_FIELD]
        .transform(
            lambda x:
            x.rolling(
                FEATURE_CONFIG["rolling_window"],
                min_periods=FEATURE_CONFIG["minimum_periods"]
            ).std()
        )
    )
    # Z Score
    market_df["ZScore"] = (
        market_df[PRICE_FIELD]
        -
        market_df["RollingMean"]
    ) / market_df["RollingStd"]
    # ----------------------------------------------------------
    # Source Divergence
    # ----------------------------------------------------------
    market_df["SourceDifference"] = (
        abs(
            market_df[PRICE_FIELD]
            -
            market_df[COMPARISON_PRICE_FIELD]
        )
    )
    market_df["SourceDifferencePct"] = (
        market_df["SourceDifference"]
        /
        market_df[COMPARISON_PRICE_FIELD]
    )
    # ----------------------------------------------------------
    # Simulate Feed Latency
    # ----------------------------------------------------------
    market_df["FeedLatencySeconds"] = np.random.randint(
        0,
        600,
        len(market_df)
    )
    # ----------------------------------------------------------
    # Simulate Market Open
    # ----------------------------------------------------------
    market_df["MarketOpen"] = np.where(
        market_df[TIMESTAMP_FIELD].dt.dayofweek <5,
        True,
        False
    )
    # ----------------------------------------------------------
    # Market Session
    # ----------------------------------------------------------
    hour = market_df[TIMESTAMP_FIELD].dt.hour
    market_df["MarketSession"] = np.select(
        [
            hour<8,
            hour<16,
            hour<22
        ],
        [
            "Asia",
            "Europe",
            "US"
        ],
        default="After Hours"
    )
    # ----------------------------------------------------------
    # Join Exposure
    # ----------------------------------------------------------
    market_df = market_df.merge(
        exposure_df,
        on=INSTRUMENT_FIELD,
        how="left"
    )
    # ----------------------------------------------------------
    # Sample Output
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # Feature Summary
    # ----------------------------------------------------------
    feature_summary = pd.DataFrame({
        "Feature":[
            "Price Change",
            "Rolling Mean",
            "Rolling Std",
            "Z Score",
            "Source Difference",
            "Feed Latency",
            "Market Session",
            "Portfolio Exposure"
        ],
        "Purpose":[
            "Detect sudden movements",
            "Expected price",
            "Historical volatility",
            "Statistical anomaly",
            "Vendor disagreement",
            "Stale feed detection",
            "Trading hours context",
            "Business impact"
        ]
    })
    # ----------------------------------------------------------
    # Visualisation 1
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # Visualisation 2
    # ----------------------------------------------------------
    # Preserve notebook chart sampling: advances the RNG used by later stages.
    market_df.sample(800)
    # ----------------------------------------------------------
    # Save enriched dataset
    # ----------------------------------------------------------
    market_df.to_csv(
        PROJECT_ROOT /
        "data/processed/enriched_market_data.csv",
        index=False
    )

