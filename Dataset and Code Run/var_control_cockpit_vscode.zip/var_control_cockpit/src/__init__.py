"""Local analytical stages corresponding to notebook Blocks 1–9."""
