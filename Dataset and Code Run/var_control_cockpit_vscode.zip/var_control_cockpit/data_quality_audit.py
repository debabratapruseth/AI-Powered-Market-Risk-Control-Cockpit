"""Read-only console audit of this cockpit's saved FX raw and processed CSVs.

Run: python data_quality_audit.py [--root /path/to/cockpit]
No pipeline imports, generation, API calls, persistence or data repair.
Exit 0: no review items; 1: CHECK items; 2: configuration unavailable.
"""
import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

RAW = {
    'market_data.csv': ['Timestamp', 'RiskFactor', 'ReutersPrice', 'BloombergPrice', 'InjectedStale', 'InjectedOutlier'],
    'exposures.csv': ['Portfolio', 'RiskFactor', 'ExposureUSD', 'VaRContribution', 'Criticality'],
    'historical_alerts.csv': ['AlertID', 'RiskFactor', 'AlertType', 'ResolvedAs', 'RootCause'],
    'scenarios.csv': ['ScenarioID', 'Scenario', 'ShockPercent'],
}
PROCESSED = ['enriched_market_data.csv', 'rule_observation_alerts.csv', 'rule_portfolio_alerts.csv',
             'market_data_with_rules.csv', 'market_data_with_ai.csv', 'context_observations.csv',
             'market_data_with_context.csv', 'market_data_prioritised.csv', 'investigation_pack.csv']
OBS = ['RiskFactor', 'Timestamp']
PORT = OBS + ['Portfolio']
BOOLS = ['InjectedStale', 'InjectedOutlier', 'MarketOpen', 'HasRuleAlert', 'AIAnomaly',
         'CombinedAlert', 'MarketWideMove', 'PriceUnchanged', 'Context_MarketClosed',
         'Rule_Stale', 'Rule_LargeMove', 'Rule_ZScoreOutlier', 'Rule_SourceDivergence', 'Rule_HighLatency']

RULE_FIELDS = ['HasRuleAlert','AlertTypes','RuleSeverity','RuleSeverityScore','RuleEvidence',
               'Rule_Stale','Rule_LargeMove','Rule_ZScoreOutlier','Rule_SourceDivergence','Rule_HighLatency']
ML_FIELDS = ['AIAnomaly','AIScore','AISeverity','AISeverityScore','CombinedAlert','AIExplanation']
CONTEXT_FIELDS = ['VendorAgreement','PeerDeviation','MarketWideMove','HistoricalCount','MostCommonRootCause',
                  'ConfidenceScore','VendorConfidenceComponent','PeerConfidenceComponent','HistoricalConfidenceComponent']
IMPACT_FIELDS = ['ScenarioID','Scenario','ShockPercent','ExposureUSD','VaRContribution','EstimatedPnL','EstimatedVaRImpact',
                 'BusinessImpactScore','FinalPriority','Recommendation','BusinessRecommendation']
STAGE_REQUIRED = {
    'enriched_market_data.csv': ['PreviousPrice','PriceChange','PctChange','RollingMean','RollingStd','ZScore',
        'SourceDifference','SourceDifferencePct','FeedLatencySeconds','ExposureUSD','VaRContribution'],
    'rule_observation_alerts.csv': RULE_FIELDS,
    'rule_portfolio_alerts.csv': RULE_FIELDS,
    'market_data_with_rules.csv': RULE_FIELDS,
    'market_data_with_ai.csv': RULE_FIELDS + ML_FIELDS,
    'context_observations.csv': CONTEXT_FIELDS + ['AlertTypes','HasRuleAlert','AIAnomaly'],
    'market_data_with_context.csv': RULE_FIELDS + ML_FIELDS + CONTEXT_FIELDS,
    'market_data_prioritised.csv': RULE_FIELDS + ML_FIELDS + CONTEXT_FIELDS + IMPACT_FIELDS,
    'investigation_pack.csv': RULE_FIELDS + ML_FIELDS + CONTEXT_FIELDS + IMPACT_FIELDS + ['LikelyRootCause'],
}


def missing(series):
    return series.isna() | series.astype('string').str.strip().eq('').fillna(False)


def truth(series):
    # Never use astype(bool): the string "False" is truthy in Python.
    return series.astype('string').str.strip().str.lower().eq('true').fillna(False)


class Audit:
    def __init__(self, root, config):
        self.root, self.config = root, config
        self.counts = Counter()
        self.reviews, self.files, self.intentional = [], {}, []
        self.loaded = Counter()

    def emit(self, status, message):
        self.counts[status] += 1
        print(f'[{status}] {message}')
        if status == 'CHECK':
            self.reviews.append(message)

    def check(self, condition, message):
        self.emit('PASS' if bool(condition) else 'CHECK', message)

    def section(self, label):
        print('\n' + '=' * 60 + '\n' + label + '\n' + '=' * 60)

    def require(self, frame, columns, label):
        absent = sorted(set(columns) - set(frame))
        self.check(not absent, f'{label}: required columns present' + (f'; missing {absent}' if absent else ''))
        return not absent

    def load(self, folder, name, required):
        label = f'{folder}/{name}'
        self.section(label)
        try:
            frame = pd.read_csv(self.root / 'data' / folder / name)
        except (OSError, ValueError, pd.errors.ParserError) as error:
            self.emit('CHECK', f'{label}: cannot read CSV ({type(error).__name__}: {error})')
            return None
        self.loaded[folder] += 1
        self.files[name] = frame
        print(f'Rows: {len(frame):,}; Columns: {len(frame.columns)}')
        print('Columns / inferred CSV dtypes: ' + ', '.join(f'{c}={t}' for c, t in frame.dtypes.items()))
        print('Missing counts (zero columns omitted): ' + str({c: int(missing(frame[c]).sum()) for c in frame if missing(frame[c]).any()}))
        self.check(len(frame) > 0, f'{label}: nonempty dataset')
        self.check(not frame.duplicated().any(), f'{label}: duplicate full rows = {int(frame.duplicated().sum())}')
        if not self.require(frame, required, label):
            return None
        for col in set(BOOLS) & set(frame):
            valid = frame[col].astype('string').str.strip().str.lower().isin(['true', 'false'])
            self.check(valid.all(), f'{label}.{col}: valid nonmissing Boolean values')
        if 'Timestamp' in frame:
            parsed = pd.to_datetime(frame.Timestamp, errors='coerce')
            self.check(parsed.notna().all(), f'{label}: Timestamp parses without missing/invalid values')
            frame['Timestamp'] = parsed
        return frame

    def key(self, frame, keys, label):
        if not self.require(frame, keys, label):
            return False
        complete = not any(missing(frame[c]).any() for c in keys)
        unique = not frame.duplicated(keys).any()
        self.check(complete, f'{label}: key {keys} complete')
        self.check(unique, f'{label}: duplicate key rows = {int(frame.duplicated(keys).sum())}')
        return complete and unique

    def stats(self, series, label, positive=False):
        number = pd.to_numeric(series, errors='coerce')
        invalid = int((~missing(series) & number.isna()).sum())
        infinite = int(np.isinf(number).sum())
        finite = number[np.isfinite(number)]
        print(f'{label}: count={len(finite)}, missing={int(missing(series).sum())}, nonnumeric={invalid}, infinite={infinite}, nonpositive={int(number.le(0).sum())}')
        if len(finite):
            print(finite.describe(percentiles=[.01, .05, .25, .5, .75, .95, .99]).rename({'50%': 'median'}).to_string())
        self.check(invalid == 0 and infinite == 0 and len(finite) == len(series), f'{label}: all values present, numeric and finite')
        if positive:
            self.check(len(finite) == len(series) and finite.gt(0).all(), f'{label}: all values positive')
        return number

    def raw(self):
        self.section('RAW DATA SUMMARY')
        frames = {name: self.load('raw', name, cols) for name, cols in RAW.items()}
        for name, frame in frames.items():
            if frame is not None:
                self.check(not any(missing(frame[c]).any() for c in frame), f'{name}: no missing raw values')
        m = frames['market_data.csv']
        if m is not None:
            self.key(m, OBS, 'Raw market observations')
            proto = self.config['prototype']
            self.check(set(m.RiskFactor.dropna()) == set(proto['currency_pairs']), 'Raw risk factors match configured universe')
            print('Unique observations:', len(m[OBS].drop_duplicates()))
            print('Rows per risk factor:\n' + m.groupby('RiskFactor').size().to_string())
            print('Timestamp minimum:', m.Timestamp.min(), 'maximum:', m.Timestamp.max(), 'duration:', m.Timestamp.max() - m.Timestamp.min())
            expected_count = 24 * proto['days_of_history']
            if m.Timestamp.notna().all() and len(m):
                grid = pd.date_range(end=m.Timestamp.max(), periods=expected_count, freq=proto['sampling_frequency'])
                for pair, group in m.groupby('RiskFactor'):
                    actual = pd.DatetimeIndex(group.Timestamp).sort_values()
                    gaps, extra = len(grid.difference(actual)), len(actual.difference(grid))
                    self.check(len(group) == expected_count and actual.equals(grid), f'{pair}: shared {proto["sampling_frequency"]} time grid; observations={len(group)}, missing intervals={gaps}, off-grid={extra}, duplicates={int(actual.duplicated().sum())}')
                setting = self.config.get('data_generation', {}).get('as_of')
                if setting and str(setting).lower() != 'system':
                    self.check(m.Timestamp.max() == pd.Timestamp(setting), 'Saved endpoint matches current configured as_of (an explicit CLI override may explain a mismatch)')
            for pair, group in m.groupby('RiskFactor'):
                for col in ['ReutersPrice', 'BloombergPrice']:
                    self.stats(group[col], f'{pair}.{col}', positive=True)
                r = pd.to_numeric(group.ReutersPrice, errors='coerce')
                b = pd.to_numeric(group.BloombergPrice, errors='coerce')
                valid = np.isfinite(r) & np.isfinite(b) & b.gt(0)
                gap = (r[valid] - b[valid]).abs()
                pct = gap / b[valid] * 100
                corr = r[valid].corr(b[valid]) if valid.sum() > 1 and r[valid].std() > 0 and b[valid].std() > 0 else np.nan
                print(f'{pair} vendor comparison ({int(valid.sum())}/{len(group)} usable): absolute difference mean/median/max={gap.mean():.8g}/{gap.median():.8g}/{gap.max():.8g}; percentage difference mean/median/max={pct.mean():.6g}%/{pct.median():.6g}%/{pct.max():.6g}%; correlation={corr:.6g}')
            self.emit('INFO', 'Price statistics are per FX pair: pooled means/correlations would mix incompatible price scales. Source percentage difference uses Bloomberg as denominator, matching enrichment.')
            for col in ['InjectedStale', 'InjectedOutlier']:
                n = int(truth(m[col]).sum())
                note = f'{col}: {n} intentional observations ({100*n/len(m):.4f}%)' if len(m) else f'{col}: empty dataset'
                self.intentional.append(note)
                self.emit('INFO', note + '; abnormality is not a dataset-quality failure')
                print(m.assign(_flag=truth(m[col])).groupby('RiskFactor')._flag.sum().to_string())
            self.emit('INFO', f'Injection overlap: {int((truth(m.InjectedStale) & truth(m.InjectedOutlier)).sum())}; flags record injected test cases, not guaranteed detected alerts')
        e = frames['exposures.csv']
        if e is not None:
            self.key(e, ['Portfolio', 'RiskFactor'], 'Exposures')
            for col in ['Portfolio', 'RiskFactor', 'Criticality']:
                print(col + ': ' + str(e[col].value_counts(dropna=False).to_dict()))
            exposure = self.stats(e.ExposureUSD, 'ExposureUSD', True)
            self.check(exposure.ge(5_000_000).all() and exposure.lt(50_000_000).all(), 'Exposure values within actual generator range [$5M, $50M)')
            self.check(set(e.Portfolio.dropna()) == {'FX Trading','Treasury','Corporate Banking','Private Banking'}, 'Portfolios match the four portfolios defined in the generator')
            v = self.stats(e.VaRContribution, 'Portfolio Risk Contribution (%)', True)
            self.check(v.between(1, 20).all(), 'Synthetic portfolio-risk contribution within generator range 1–20%')
            self.check(e.Criticality.isin(['Critical','High','Medium','Low']).all(), 'Criticality labels match generator vocabulary')
            expected = {(p, r) for p in e.Portfolio.dropna().unique() for r in self.config['prototype']['currency_pairs']}
            self.check(set(e[['Portfolio','RiskFactor']].itertuples(index=False,name=None)) == expected, 'Exposure matrix covers every observed portfolio/configured risk factor')
            self.emit('INFO', 'Portfolio Risk Contribution is a synthetic exposure attribute, not regulatory VaR; exposure range in generator is $5M to below $50M')
        h = frames['historical_alerts.csv']
        if h is not None:
            self.key(h, ['AlertID'], 'Historical alerts')
            self.check(len(h) == 50, 'Historical alert count matches generator size 50')
            self.check(h.RootCause.isin(['Vendor Delay','Market Movement','Bad Mapping','Holiday','Missing Feed']).all(), 'Historical root-cause vocabulary valid')
            for col in ['RiskFactor','AlertType','RootCause','ResolvedAs']:
                print(col + ': ' + str(h[col].value_counts(dropna=False).to_dict()))
            self.check(h.RiskFactor.isin(self.config['prototype']['currency_pairs']).all(), 'Historical risk factors in configured universe')
            self.check(h.AlertType.isin(['Stale','Outlier','Missing','Source Divergence']).all(), 'Historical alert categories valid')
            self.check(h.ResolvedAs.isin(['True Issue','False Positive']).all(), 'Historical resolutions valid')
            repeated = h.drop(columns='AlertID').duplicated().sum()
            self.emit('INFO', f'Historical records repeating non-ID attributes: {repeated}; repeated categories/causes are allowed synthetic history, not duplicate identities')
        s = frames['scenarios.csv']
        if s is not None:
            self.key(s, ['ScenarioID'], 'Scenarios')
            print(s.to_string(index=False))
            shocks = self.stats(s.ShockPercent, 'Scenario shock (%)')
            settings = self.config['scenarios']
            self.check(len(s) == len(settings['names']) and s.Scenario.tolist() == settings['names'], 'Scenario names/order/count match configuration')
            self.check(shocks.between(settings['shock_percent_min'], settings['shock_percent_max']).all(), 'Shocks within configured range; negative and positive shocks are intentional')
        return frames

    def expected_missing(self, d, raw):
        allowed = {c: pd.Series(False, index=d.index) for c in d}
        m, h = raw.get('market_data.csv'), raw.get('historical_alerts.csv')
        if m is not None and set(OBS) <= set(d):
            ordered = m.sort_values(OBS).copy()
            ordered['_ordinal'] = ordered.groupby('RiskFactor').cumcount()
            lookup = ordered.drop_duplicates(OBS).set_index(OBS)._ordinal
            ordinal = pd.Series(lookup.reindex(pd.MultiIndex.from_frame(d[OBS])).to_numpy(), index=d.index)
            for c in ['PreviousPrice','PriceChange','PctChange','AbsolutePctChange']:
                if c in d: allowed[c] = ordinal.eq(0)
            warm = ordinal.lt(self.config['feature_engineering']['minimum_periods'] - 1)
            for c in ['RollingMean','RollingStd','ZScore']:
                if c in d: allowed[c] = warm.copy()
            if 'ZScore' in d and 'RollingStd' in d:
                allowed['ZScore'] |= pd.to_numeric(d.RollingStd,errors='coerce').eq(0)
            # Market/peer aggregates are undefined only when movements are unavailable.
            first_times = ordered[ordered._ordinal.eq(0)].Timestamp
            all_first = set(first_times) if first_times.nunique() == 1 else set()
            for c in ['AvgMarketMove','AvgAbsMove','MarketVolatility','PeerAverageMove','PeerStdMove']:
                if c in d: allowed[c] = d.Timestamp.isin(all_first)
        if 'AlertID' in d and 'HasRuleAlert' in d:
            allowed['AlertID'] = ~truth(d.HasRuleAlert)
        if h is not None and {'RiskFactor','AlertTypes'} <= set(d):
            primary = d.AlertTypes.astype('string').str.split('|').str[0].str.strip().replace(self.config['context']['historical_similarity']['alert_type_mapping'])
            history_keys = set(h[['RiskFactor','AlertType']].itertuples(index=False,name=None))
            absent = pd.Series([(r,t) not in history_keys for r,t in zip(d.RiskFactor,primary)],index=d.index)
            for c in ['HistoricalCount','MostCommonRootCause','AlertType']:
                if c in d: allowed[c] = absent
        return allowed

    def processed(self, raw):
        self.section('PROCESSED DATA SUMMARY')
        for name in PROCESSED:
            observation_level = name in ['context_observations.csv','rule_observation_alerts.csv']
            keys = OBS if observation_level else PORT
            required = keys + ['ReutersPrice','BloombergPrice'] + STAGE_REQUIRED[name]
            if name != 'enriched_market_data.csv' and name != 'context_observations.csv': required += ['ObservationID','HasRuleAlert','AlertID']
            if name == 'investigation_pack.csv': required += ['investigation_id','CombinedAlert','InvestigationJSON','NextAction']
            d = self.load('processed',name,required)
            if d is None: continue
            self.key(d,keys,name)
            if 'ObservationID' in d:
                expected = d.RiskFactor.astype('string') + '_' + d.Timestamp.dt.strftime('%Y%m%d_%H%M%S')
                self.check(d.ObservationID.eq(expected).all(), name + ': ObservationID matches saved instrument/timestamp')
                idkeys = ['ObservationID'] if observation_level else ['ObservationID','Portfolio']
                self.key(d,idkeys,name)
            if 'investigation_id' in d: self.key(d,['investigation_id'],name)
            allowed = self.expected_missing(d,raw)
            unexpected, structural = {}, {}
            for c in d:
                gaps = missing(d[c]); n = int((gaps & ~allowed[c]).sum())
                if n: unexpected[c] = n
                n = int((gaps & allowed[c]).sum())
                if n: structural[c] = n
            self.emit('INFO', f'{name}: verified structural missing counts = {structural}')
            self.check(not unexpected, f'{name}: unexpected missing counts = {unexpected}')
            numeric = d.select_dtypes(include='number')
            infinities = {c:int(np.isinf(numeric[c]).sum()) for c in numeric if np.isinf(numeric[c]).any()}
            self.check(not infinities, f'{name}: infinite numeric values = {infinities}')
            for c in ['ConfidenceScore','BusinessImpactScore','RuleSeverityScore','AISeverityScore']:
                if c in d:
                    n = pd.to_numeric(d[c],errors='coerce')
                    self.check(n.notna().all() and n.between(0,100).all(), f'{name}.{c}: complete finite 0–100 saved score')
            if 'AlertID' in d and 'HasRuleAlert' in d:
                active = truth(d.HasRuleAlert)
                self.check(d.loc[active,'AlertID'].eq('RULE_'+d.loc[active,'ObservationID']).all() and missing(d.loc[~active,'AlertID']).all(), f'{name}: Rule Alert ID present only on rule detections')
            if name == 'investigation_pack.csv':
                self.check(truth(d.CombinedAlert).all(), 'Investigation Pack contains detected rows only')
                invalid = 0
                for row in d.itertuples():
                    try:
                        payload=json.loads(row.InvestigationJSON)
                        invalid += not isinstance(payload,dict) or payload.get('investigation_id') != row.investigation_id
                    except (ValueError,TypeError): invalid += 1
                self.check(invalid == 0, f'Investigation JSON identity mismatches/parse errors = {invalid}')

    def compare(self, source, target, keys, label):
        if source is None or target is None:
            self.emit('CHECK', label + ': lineage unavailable because a source/target is missing')
            return
        if any(not set(keys) <= set(d) or d.duplicated(keys).any() or any(missing(d[k]).any() for k in keys) for d in [source,target]):
            self.emit('CHECK', label + ': cannot establish lineage with missing/duplicate business keys')
            return
        a,b=source.set_index(keys).sort_index(),target.set_index(keys).sort_index()
        same = a.index.equals(b.index)
        self.check(same, label + f': business-key sets match ({len(a)} → {len(b)})')
        if not same:return
        changed=[]
        for c in a.columns.intersection(b.columns):
            if pd.api.types.is_numeric_dtype(a[c]) and pd.api.types.is_numeric_dtype(b[c]):
                equal=np.isclose(a[c].to_numpy(dtype=float),b[c].to_numpy(dtype=float),rtol=1e-12,atol=1e-10,equal_nan=True).all()
            else:equal=(a[c].eq(b[c])|(a[c].isna()&b[c].isna())).all()
            if not equal:changed.append(c)
        self.check(not changed,label+': carried saved fields unchanged; differing columns='+str(changed))

    def lineage(self, raw):
        self.section('SAVED DATA LINEAGE')
        self.emit('INFO','Numeric lineage comparison permits CSV round-trip differences only (rtol=1e-12, atol=1e-10); keys/text/booleans must match exactly. No scores are recalculated.')
        get=self.files.get
        m,e=raw.get('market_data.csv'),raw.get('exposures.csv')
        if m is not None and e is not None:
            expected=m.merge(e,on='RiskFactor',how='inner')
            self.compare(expected,get('enriched_market_data.csv'),PORT,'Raw market × portfolio exposures → enriched')
        chain=['enriched_market_data.csv','market_data_with_rules.csv','market_data_with_ai.csv','market_data_with_context.csv','market_data_prioritised.csv']
        for source,target in zip(chain,chain[1:]):self.compare(get(source),get(target),PORT,source+' → '+target)
        rules=get('market_data_with_rules.csv')
        if rules is not None and 'HasRuleAlert' in rules:
            selected=rules[truth(rules.HasRuleAlert)]
            self.compare(selected,get('rule_portfolio_alerts.csv'),PORT,'Rule detections → portfolio alerts')
            self.compare(selected.drop(columns=['Portfolio','ExposureUSD','VaRContribution','Criticality'],errors='ignore').drop_duplicates(OBS),get('rule_observation_alerts.csv'),OBS,'Unique rule detections → observation alerts')
        context=get('market_data_with_context.csv')
        if context is not None:
            self.compare(context.drop_duplicates(OBS),get('context_observations.csv'),OBS,'Portfolio context → unique context observations')
        priority=get('market_data_prioritised.csv')
        if priority is not None and 'CombinedAlert' in priority:
            self.compare(priority[truth(priority.CombinedAlert)],get('investigation_pack.csv'),PORT,'Detected prioritised rows → Investigation Pack')

    def run(self):
        raw=self.raw()
        self.processed(raw)
        self.lineage(raw)
        self.section('AUDIT SUMMARY')
        print(f'Raw files checked: {self.loaded["raw"]}/{len(RAW)}\nProcessed files checked: {self.loaded["processed"]}/{len(PROCESSED)}')
        print(f'Structural/quality checks passed: {self.counts["PASS"]}\nItems requiring review: {self.counts["CHECK"]}')
        print('Intentional test conditions: ' + '; '.join(self.intentional))
        for i,message in enumerate(self.reviews,1):print(f'  {i}. {message}')
        print('Overall audit status: ' + ('CHECK — review the listed findings; data was not changed' if self.reviews else 'PASS — checked structures and lineage are consistent'))
        print('Scope: saved-data quality, not model validation or proof of real-market accuracy. No data or pipeline files were modified.')
        return 1 if self.reviews else 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    try:
        config=yaml.safe_load((args.root/'config/asset_packs/fx.yaml').read_text())
        for section in ['prototype','feature_engineering','context','scenarios']:
            if not isinstance(config.get(section),dict):raise ValueError('Missing configuration section '+section)
    except (OSError,ValueError,AttributeError,yaml.YAMLError) as error:
        print(f'[CHECK] Configuration unavailable: {error}')
        return 2
    try:
        return Audit(args.root,config).run()
    except (KeyError,ValueError,TypeError,AttributeError) as error:
        print(f'[CHECK] Audit could not complete a dependent check: {type(error).__name__}: {error}')
        print('Overall audit status: CHECK — incomplete audit; no data was changed')
        return 1


if __name__=='__main__':
    raise SystemExit(main())
