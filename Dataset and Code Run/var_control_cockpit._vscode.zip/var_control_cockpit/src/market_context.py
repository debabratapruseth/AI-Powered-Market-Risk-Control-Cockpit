"""Block 6: market context with contemporaneous FX return-gap peer evidence."""
import json
import random
import numpy as np
import pandas as pd



def add_peer_context(observations, timestamp_field='Timestamp'):
    """Contemporaneous FX return gap, in decimal percentage-point units.

    PeerDeviation = abs(PctChange - mean contemporaneous finite PctChange).
    The existing YAML threshold 0.01 now means a gap exceeding 1 percentage
    point, not a 1% difference between incomparable raw FX price levels.
    Keep the configured 15 evidence points and all other confidence components.
    PeerStdMove uses sample dispersion (ddof=1) for evidence/availability only;
    this metric is NOT a Z-score and must not be interpreted as one.

    Missing/nonfinite movements, fewer than two peers, and zero/missing
    dispersion produce a neutral 0.0 deviation. No future rows are used.
    Each instrument must occur once per timestamp before this function runs.
    Production peer groups should reflect currency-factor relationships;
    the available FX universe is only a prototype contemporaneous peer group.
    """
    result = observations.copy()
    movement = pd.to_numeric(result['PctChange'], errors='coerce').replace([np.inf, -np.inf], np.nan)
    grouped = movement.groupby(result[timestamp_field])
    result['PeerAverageMove'] = grouped.transform('mean')
    result['PeerStdMove'] = grouped.transform('std')
    valid = movement.notna() & result['PeerStdMove'].gt(0) & np.isfinite(result['PeerStdMove'])
    result['PeerDeviation'] = (movement - result['PeerAverageMove']).abs().where(valid, 0.0).fillna(0.0)
    return result

def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    CONTEXT_CONFIG = CONFIG["context"]
    CONFIDENCE_CONFIG = CONFIG["confidence"]
    INSTRUMENT_FIELD = DATA_CONFIG["instrument_field"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PRICE_FIELD = DATA_CONFIG["price_field"]
    COMPARISON_PRICE_FIELD = DATA_CONFIG["source_field"][DATA_CONFIG["required_sources"][1]]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 6
    #
    # MARKET CONTEXT & EXPLAINABILITY
    #
    # PURPOSE
    # -------
    # 1. Understand whether an alert is isolated or market-wide
    # 2. Compare against peer instruments
    # 3. Calculate market movement statistics
    # 4. Find historical similarity
    # 5. Produce analyst recommendations
    #
    # Output:
    # market_data_with_context.csv
    # ============================================================
    # ----------------------------------------------------------
    # Load AI output
    # ----------------------------------------------------------
    market_df = pd.read_csv(
        PROJECT_ROOT /
        "data/processed/market_data_with_ai.csv",
        parse_dates=[TIMESTAMP_FIELD]
    )
    historical_df = pd.read_csv(
        PROJECT_ROOT /
        "data/raw/historical_alerts.csv"
    )
    # ----------------------------------------------------------
    # Create unique observation dataset
    # ----------------------------------------------------------
    obs_cols = [
        TIMESTAMP_FIELD,
        INSTRUMENT_FIELD,
        PRICE_FIELD,
        COMPARISON_PRICE_FIELD,
        "PctChange",
        "ZScore",
        "SourceDifferencePct",
        "FeedLatencySeconds",
        "HasRuleAlert",
        "AIAnomaly",
        "RuleSeverityScore",
        "AISeverityScore",
        "AlertTypes"
    ]
    obs_df = (
        market_df[obs_cols]
        .drop_duplicates(
            subset=[TIMESTAMP_FIELD,INSTRUMENT_FIELD]
        )
    )
    # ----------------------------------------------------------
    # Overall Market Movement
    # ----------------------------------------------------------
    market_stats = (
        obs_df
        .groupby(TIMESTAMP_FIELD)
        .agg(
            AvgMarketMove=("PctChange","mean"),
            AvgAbsMove=("PctChange",
                        lambda x:x.abs().mean()),
            MarketVolatility=("PctChange","std")
        )
        .reset_index()
    )
    obs_df = obs_df.merge(
        market_stats,
        on=TIMESTAMP_FIELD,
        how="left"
    )
    # ----------------------------------------------------------
    # Peer Comparison
    # ----------------------------------------------------------
    obs_df = add_peer_context(obs_df, TIMESTAMP_FIELD)
    # ----------------------------------------------------------
    # Vendor Consensus
    # ----------------------------------------------------------
    obs_df["VendorAgreement"] = np.where(
        obs_df["SourceDifferencePct"]<CONTEXT_CONFIG["vendor_agreement"]["strong_below"],
        "Strong",
        np.where(
            obs_df["SourceDifferencePct"]<CONTEXT_CONFIG["vendor_agreement"]["moderate_below"],
            "Moderate",
            "Weak"
        )
    )
    # ----------------------------------------------------------
    # Market Event Indicator
    # ----------------------------------------------------------
    obs_df["MarketWideMove"] = np.where(
        obs_df["AvgAbsMove"]>CONTEXT_CONFIG["market_wide_move_threshold"],
        True,
        False
    )
    # ----------------------------------------------------------
    # Historical Similarity
    # ----------------------------------------------------------
    history_lookup = (
        historical_df
        .groupby(
            [INSTRUMENT_FIELD,"AlertType"]
        )
        .agg(
            HistoricalCount=("AlertID","count"),
            MostCommonRootCause=(
                "RootCause",
                lambda x:x.mode().iloc[0]
            )
        )
        .reset_index()
    )
    # Simplify alert type
    obs_df["PrimaryAlert"] = (
        obs_df["AlertTypes"]
        .str.split("|")
        .str[0]
        .str.strip()
    )
    mapping = CONTEXT_CONFIG["historical_similarity"]["alert_type_mapping"]
    obs_df["PrimaryAlert"] = (
        obs_df["PrimaryAlert"]
        .replace(mapping)
    )
    obs_df = obs_df.merge(
        history_lookup,
        left_on=[INSTRUMENT_FIELD,"PrimaryAlert"],
        right_on=[INSTRUMENT_FIELD,"AlertType"],
        how="left"
    )
    # ----------------------------------------------------------
    # Confidence Score
    # ----------------------------------------------------------
    confidence = (
          obs_df["HasRuleAlert"].astype(int)*CONFIDENCE_CONFIG["weights"]["rule_alert"]
        + obs_df["AIAnomaly"].astype(int)*CONFIDENCE_CONFIG["weights"]["ml_anomaly"]
        + (obs_df["VendorAgreement"]=="Weak").astype(int)*CONFIDENCE_CONFIG["weights"]["vendor_disagreement"]
        + (obs_df["PeerDeviation"]>CONTEXT_CONFIG["peer_analysis"]["deviation_threshold"]).astype(int)*CONFIDENCE_CONFIG["weights"]["peer_deviation"]
        + obs_df["HistoricalCount"].fillna(0).clip(0,CONFIDENCE_CONFIG["historical_count_cap"])
          * (CONFIDENCE_CONFIG["weights"]["historical_recurrence"] / CONFIDENCE_CONFIG["historical_count_cap"])
    )
    obs_df["ConfidenceScore"] = confidence.clip(0,CONFIDENCE_CONFIG["maximum_score"])
    # ----------------------------------------------------------
    # Recommendation
    # ----------------------------------------------------------
    def recommendation(row):
        if row["ConfidenceScore"]>=CONTEXT_CONFIG["recommendation_thresholds"]["escalate"]:
            return "Escalate Immediately"
        if row["ConfidenceScore"]>=CONTEXT_CONFIG["recommendation_thresholds"]["investigate"]:
            return "Investigate"
        if row["MarketWideMove"]:
            return "Likely Genuine Market Move"
        if row["VendorAgreement"]=="Weak":
            return "Verify Vendor Feed"
        return "Monitor"
    obs_df["Recommendation"] = obs_df.apply(
        recommendation,
        axis=1
    )
    # ----------------------------------------------------------
    # Merge back to portfolio level
    # ----------------------------------------------------------
    merge_cols = [
        TIMESTAMP_FIELD,
        INSTRUMENT_FIELD,
        "AvgMarketMove",
        "AvgAbsMove",
        "MarketVolatility",
        "PeerAverageMove",
        "PeerStdMove",
        "PeerDeviation",
        "VendorAgreement",
        "MarketWideMove",
        "HistoricalCount",
        "MostCommonRootCause",
        "ConfidenceScore",
        "Recommendation"
    ]
    market_df = market_df.merge(
        obs_df[merge_cols],
        on=[TIMESTAMP_FIELD,INSTRUMENT_FIELD],
        how="left"
    )
    # ----------------------------------------------------------
    # Dashboard Tables
    # ----------------------------------------------------------
    summary = pd.DataFrame({
        "Metric":[
            "Total Observations",
            "Average Market Move",
            "Average Confidence",
            "Weak Vendor Agreement",
            "Market Wide Events"
        ],
        "Value":[
            len(obs_df),
            round(obs_df["AvgAbsMove"].mean(),5),
            round(obs_df["ConfidenceScore"].mean(),1),
            (obs_df["VendorAgreement"]=="Weak").sum(),
            obs_df["MarketWideMove"].sum()
        ]
    })
    # ----------------------------------------------------------
    # Top Alerts
    # ----------------------------------------------------------
    top = (
        obs_df
        .sort_values(
            "ConfidenceScore",
            ascending=False
        )
        .head(20)
    )
    # ----------------------------------------------------------
    # Visualisation
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # Confidence Distribution
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # Save
    # ----------------------------------------------------------
    market_df.to_csv(
        PROJECT_ROOT /
        "data/processed/market_data_with_context.csv",
        index=False
    )
    obs_df.to_csv(
        PROJECT_ROOT /
        "data/processed/context_observations.csv",
        index=False
    )

