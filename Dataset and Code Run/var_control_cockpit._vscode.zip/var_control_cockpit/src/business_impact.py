"""Notebook Block 7: business impact. Formulas and CSV handoffs retained."""
import json
import random
import numpy as np
import pandas as pd


def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    BUSINESS_IMPACT_CONFIG = CONFIG["business_impact"]
    IMPACT_WEIGHTS = BUSINESS_IMPACT_CONFIG["scoring_weights"]
    PRIORITY_CONFIG = CONFIG["priority"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PRICE_FIELD = DATA_CONFIG["price_field"]
    EXPOSURE_FIELD = DATA_CONFIG["exposure_field"]
    VAR_CONTRIBUTION_FIELD = DATA_CONFIG["var_contribution_field"]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 7
    #
    # VaR IMPACT & BUSINESS PRIORITISATION
    #
    # PURPOSE
    # -------
    # Convert technical alerts into business risk by estimating:
    #
    # • Shocked Market Price
    # • Estimated P&L Impact
    # • VaR Impact
    # • Business Impact Score
    # • Final Alert Priority
    #
    # Output:
    # market_data_prioritised.csv
    # ============================================================
    # ----------------------------------------------------------
    # Load Context Output
    # ----------------------------------------------------------
    market_df = pd.read_csv(
        PROJECT_ROOT /
        "data/processed/market_data_with_context.csv",
        parse_dates=[TIMESTAMP_FIELD]
    )
    scenario_df = pd.read_csv(
        PROJECT_ROOT /
        "data/raw/scenarios.csv"
    )
    # ----------------------------------------------------------
    # Assign Scenario
    # ----------------------------------------------------------
    #
    # Prototype behaviour:
    # Scenario assignment is synthetic for demonstration purposes.
    # A production implementation would consume approved market-risk
    # scenarios and outputs from the bank's risk engine.
    market_df["ScenarioID"] = np.random.choice(
        scenario_df["ScenarioID"],
        len(market_df)
    )
    market_df = market_df.merge(
        scenario_df,
        on="ScenarioID",
        how="left"
    )
    # ----------------------------------------------------------
    # Shocked Market Price
    # ----------------------------------------------------------
    market_df["ShockedPrice"] = (
        market_df[PRICE_FIELD]
        *
        (
            1 +
            market_df["ShockPercent"]/100
        )
    )
    # ----------------------------------------------------------
    # Estimated P&L
    # ----------------------------------------------------------
    #
    # Simple approximation:
    #
    # PnL = Exposure × Price Change %
    market_df["EstimatedPnL"] = (
        market_df[EXPOSURE_FIELD]
        *
        (
            market_df["ShockedPrice"]
            -
            market_df[PRICE_FIELD]
        )
        /
        market_df[PRICE_FIELD]
    )
    market_df["EstimatedPnL"] = (
        market_df["EstimatedPnL"]
        .round(2)
    )
    # ----------------------------------------------------------
    # Estimated VaR Impact
    # ----------------------------------------------------------
    market_df["EstimatedVaRImpact"] = (
        abs(
            market_df["EstimatedPnL"]
        )
        *
        market_df[VAR_CONTRIBUTION_FIELD]
        /100
    )
    # ----------------------------------------------------------
    # Business Impact Score
    # ----------------------------------------------------------
    impact = (
          market_df["RuleSeverityScore"]*IMPACT_WEIGHTS["rule_severity"]
        + market_df["AISeverityScore"]*IMPACT_WEIGHTS["ml_severity"]
        + market_df["ConfidenceScore"]*IMPACT_WEIGHTS["confidence"]
        + (
            market_df[VAR_CONTRIBUTION_FIELD]
            *IMPACT_WEIGHTS["var_contribution"]
          )
        + (
            market_df[EXPOSURE_FIELD]
            /
            market_df[EXPOSURE_FIELD].max()
          )*IMPACT_WEIGHTS["exposure"]
    )
    market_df["BusinessImpactScore"] = (
        impact
        .clip(0,BUSINESS_IMPACT_CONFIG["maximum_score"])
        .round(1)
    )
    # ----------------------------------------------------------
    # Final Priority
    # ----------------------------------------------------------
    conditions = [
        market_df["BusinessImpactScore"]>=PRIORITY_CONFIG["critical"],
        market_df["BusinessImpactScore"]>=PRIORITY_CONFIG["high"],
        market_df["BusinessImpactScore"]>=PRIORITY_CONFIG["medium"],
        market_df["BusinessImpactScore"]>=PRIORITY_CONFIG["low"]
    ]
    labels = [
        "Critical",
        "High",
        "Medium",
        "Low"
    ]
    market_df["FinalPriority"] = np.select(
        conditions,
        labels,
        default="Monitor"
    )
    # ----------------------------------------------------------
    # Business Recommendation
    # ----------------------------------------------------------
    def recommendation(row):
        if row["FinalPriority"]=="Critical":
            return "Escalate to Market Risk immediately"
        if row["FinalPriority"]=="High":
            return "Investigate within 1 hour"
        if row["FinalPriority"]=="Medium":
            return "Review today"
        if row["FinalPriority"]=="Low":
            return "Monitor"
        return "No action"
    market_df["BusinessRecommendation"] = (
        market_df.apply(
            recommendation,
            axis=1
        )
    )
    # ----------------------------------------------------------
    # Executive Dashboard
    # ----------------------------------------------------------
    summary = pd.DataFrame({
        "Metric":[
            "Total Alerts",
            "Critical",
            "High",
            "Medium",
            "Low",
            "Average Estimated P&L",
            "Average Business Score"
        ],
        "Value":[
            len(market_df),
            (market_df["FinalPriority"]=="Critical").sum(),
            (market_df["FinalPriority"]=="High").sum(),
            (market_df["FinalPriority"]=="Medium").sum(),
            (market_df["FinalPriority"]=="Low").sum(),
            round(
                market_df["EstimatedPnL"].mean(),
                2
            ),
            round(
                market_df["BusinessImpactScore"].mean(),
                1
            )
        ]
    })
    # ----------------------------------------------------------
    # Top Business Risks
    # ----------------------------------------------------------
    top = (
        market_df
        .sort_values(
            "BusinessImpactScore",
            ascending=False
        )
        .head(20)
    )
    # ----------------------------------------------------------
    # Priority Distribution
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # P&L vs Score
    # ----------------------------------------------------------
    # Preserve notebook chart sampling: advances the RNG used by later stages.
    market_df.sample(1500)
    # ----------------------------------------------------------
    # Save
    # ----------------------------------------------------------
    market_df.to_csv(
        PROJECT_ROOT /
        "data/processed/market_data_prioritised.csv",
        index=False
    )

