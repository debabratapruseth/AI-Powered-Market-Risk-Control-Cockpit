"""Notebook Block 8: investigation. Formulas and CSV handoffs retained."""
import json
import hashlib
import re
import unicodedata
import random
import numpy as np
import pandas as pd



def validate_investigation_ids(frame):
    """Never repair duplicate or absent identities by dropping evidence rows."""
    if 'investigation_id' not in frame:
        raise ValueError('Investigation Pack requires investigation_id.')
    ids = frame['investigation_id']
    if ids.isna().any() or ids.astype(str).str.strip().eq('').any() or ids.duplicated().any():
        raise ValueError('Investigation IDs must be non-null, non-blank and unique for every row.')
    if ids.nunique() != len(frame):
        raise ValueError('Investigation ID count must equal Investigation Pack row count.')


def investigation_ids(frame, portfolio_field='Portfolio'):
    """Identity is ObservationID + Portfolio, independent of detector and scenario.

    The actual baseline has 7,556 distinct keys for 7,556 investigation rows.
    Normalized labels receive a deterministic SHA-256 suffix so punctuation,
    case and Unicode variants cannot silently collapse to a shared identifier.
    Final uniqueness is validated, including any truncated-hash collision.
    """
    fields = ['ObservationID', portfolio_field]
    if not set(fields) <= set(frame):
        raise ValueError('Investigation identity requires ObservationID and portfolio.')
    keys = frame[fields]
    if keys.isna().any().any() or keys.astype(str).apply(lambda col: col.str.strip().eq('')).any().any():
        raise ValueError('Investigation natural key contains null or blank values.')
    if keys.duplicated().any():
        raise ValueError('ObservationID + portfolio is not unique; a stable business dimension must be reviewed. No rows were deduplicated.')

    def make_id(values):
        raw = [str(value) for value in values]
        normalized = [re.sub(r'[^A-Z0-9]+', '_', unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode().upper()).strip('_') for value in raw]
        # Case, spaces, underscores and punctuation can normalize identically.
        # Hash the original key on every row for subset-independent identities.
        digest = hashlib.sha256(json.dumps(raw, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()[:12].upper()
        suffix = '_' + digest
        return 'INV_' + '_'.join(normalized) + suffix

    ids = pd.Series([make_id(values) for values in keys.itertuples(index=False, name=None)], index=frame.index, dtype='string')
    # Also catches case/space-normalization collisions in otherwise canonical keys.
    collisions = ids.duplicated(keep=False)
    if collisions.any():
        # Fail rather than making an ID dependent on its surrounding population.
        raise ValueError('Normalized investigation IDs collide; review stable key normalization.')
    validate_investigation_ids(pd.DataFrame({'investigation_id': ids}))
    return ids

def run(project_root, config):
    """Execute this notebook stage using explicit root/config and saved CSV handoffs."""
    PROJECT_ROOT = project_root
    CONFIG = config
    DATA_CONFIG = CONFIG["data"]
    INSTRUMENT_FIELD = DATA_CONFIG["instrument_field"]
    TIMESTAMP_FIELD = DATA_CONFIG["timestamp_field"]
    PORTFOLIO_FIELD = DATA_CONFIG["portfolio_field"]
    EXPOSURE_FIELD = DATA_CONFIG["exposure_field"]
    # TODO: Candidate for future Asset Control Pack configuration
    # ============================================================
    # BLOCK 8
    #
    # ALERT INVESTIGATION PACK
    #
    # PURPOSE
    # -------
    # Consolidate all evidence into a structured investigation
    # package ready for the LLM.
    #
    # The LLM will NEVER analyse raw data.
    # Instead it will receive only this evidence package.
    #
    # Output
    # ------
    # investigation_pack.csv
    # ============================================================
    # ----------------------------------------------------------
    # Load prioritised alerts
    # ----------------------------------------------------------
    market_df = pd.read_csv(
        PROJECT_ROOT /
        "data/processed/market_data_prioritised.csv",
        parse_dates=[TIMESTAMP_FIELD]
    )
    # ----------------------------------------------------------
    # Keep only alerts
    # ----------------------------------------------------------
    alerts = market_df[
        market_df["CombinedAlert"]
    ].copy()
    alerts.insert(0, "investigation_id", investigation_ids(alerts, PORTFOLIO_FIELD))
    # ----------------------------------------------------------
    # Determine Primary Root Cause
    # ----------------------------------------------------------
    def determine_root_cause(row):
        if row["Rule_Stale"]:
            return "Possible stale market data"
        if row["Rule_SourceDivergence"]:
            return "Vendor price disagreement"
        if row["Rule_HighLatency"]:
            return "Delayed market data feed"
        if row["Rule_ZScoreOutlier"]:
            return "Extreme statistical movement"
        if row["Rule_LargeMove"]:
            return "Large market movement"
        if row["AIAnomaly"]:
            return "Multivariate statistical anomaly"
        return "Unknown"
    alerts["LikelyRootCause"] = alerts.apply(
        determine_root_cause,
        axis=1
    )
    # ----------------------------------------------------------
    # Suggested Next Action
    # ----------------------------------------------------------
    def next_action(row):
        if row["FinalPriority"]=="Critical":
            return (
                "Immediately contact Market Data "
                "Operations and Market Risk."
            )
        if row["Rule_SourceDivergence"]:
            return (
                "Compare Reuters and Bloomberg."
            )
        if row["Rule_HighLatency"]:
            return (
                "Check feed latency and infrastructure."
            )
        if row["Rule_Stale"]:
            return (
                "Verify vendor refresh schedule."
            )
        if row["MarketWideMove"]:
            return (
                "Check external market news."
            )
        return "Review manually."
    alerts["NextAction"] = alerts.apply(
        next_action,
        axis=1
    )
    # ----------------------------------------------------------
    # Build Investigation JSON
    # ----------------------------------------------------------
    def build_pack(row):
        return {
            "investigation_id": row["investigation_id"],
            "alert_id":row["AlertID"],
            "timestamp":str(row[TIMESTAMP_FIELD]),
            "portfolio":row[PORTFOLIO_FIELD],
            "risk_factor":row[INSTRUMENT_FIELD],
            "scenario":row["Scenario"],
            "priority":row["FinalPriority"],
            "business_score":
                float(row["BusinessImpactScore"]),
            "confidence":
                float(row["ConfidenceScore"]),
            "estimated_pnl":
                float(row["EstimatedPnL"]),
            "estimated_var":
                float(row["EstimatedVaRImpact"]),
            "exposure":
                float(row[EXPOSURE_FIELD]),
            "rule_alert":
                bool(row["HasRuleAlert"]),
            "ai_alert":
                bool(row["AIAnomaly"]),
            "rule_types":
                row["AlertTypes"],
            "rule_evidence":
                row["RuleEvidence"],
            "vendor_agreement":
                row["VendorAgreement"],
            "peer_deviation":
                float(row["PeerDeviation"]),
            "peer_deviation_method": "Absolute gap from contemporaneous mean FX percentage movement; not a Z-score",
            "peer_deviation_units": "decimal percentage-point movement (0.01 = 1 percentage point)",
            "peer_deviation_threshold": CONFIG["context"]["peer_analysis"]["deviation_threshold"],
            "market_wide":
                bool(row["MarketWideMove"]),
            "historical_root_cause":
                row["MostCommonRootCause"],
            "likely_root_cause":
                row["LikelyRootCause"],
            "recommendation":
                row["BusinessRecommendation"],
            "next_action":
                row["NextAction"]
        }
    alerts["InvestigationPack"] = alerts.apply(
        build_pack,
        axis=1
    )
    # ----------------------------------------------------------
    # Save JSON string
    # ----------------------------------------------------------
    alerts["InvestigationJSON"] = alerts[
        "InvestigationPack"
    ].apply(
        lambda x: json.dumps(
            x,
            indent=2
        )
    )
    # ----------------------------------------------------------
    # Executive Summary
    # ----------------------------------------------------------
    summary = pd.DataFrame({
        "Metric":[
            "Investigation Packs",
            "Critical",
            "High",
            "Average Confidence",
            "Average Business Score"
        ],
        "Value":[
            len(alerts),
            (alerts["FinalPriority"]=="Critical").sum(),
            (alerts["FinalPriority"]=="High").sum(),
            round(alerts["ConfidenceScore"].mean(),1),
            round(alerts["BusinessImpactScore"].mean(),1)
        ]
    })
    # ----------------------------------------------------------
    # Sample Investigation Pack
    # ----------------------------------------------------------
    sample = alerts.iloc[0] if not alerts.empty else None
    # ----------------------------------------------------------
    # Dashboard
    # ----------------------------------------------------------
    # ----------------------------------------------------------
    # Save
    # ----------------------------------------------------------
    validate_investigation_ids(alerts)
    alerts.to_csv(
        PROJECT_ROOT /
        "data/processed/investigation_pack.csv",
        index=False
    )
